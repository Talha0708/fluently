// src/data/curriculumData.ts
import { ALL_WORDS_DATABASE } from './wordsData';
import { SENTENCE_BANK } from './sentencesData';

export interface Question {
  id: string;
  type: 'mcq' | 'reorder' | 'listening' | 'matching';
  prompt: string;
  questionEn?: string;
  audioText?: string;
  options?: string[];
  answer?: string | string[];
  words?: string[];
  pairs?: { en: string; bn: string }[];
  hint?: string;
}

export interface Lesson {
  id: string;
  title: string;
  xp: number;
  count?: number;
  questions: Question[];
  isExam?: boolean;
  moduleId?: string;
}

export interface CurriculumModule {
  id: string;
  title: string;
  desc: string;
  icon: string;
  bg?: string;
  stageId?: 'A1' | 'A2' | 'B1' | 'B2' | 'C1';
  stageName?: string;
  kind?: 'core' | 'word' | 'sent';
  kindNo?: number;
  lessons: Lesson[];
  from?: number;
  to?: number;
}

export interface StageInfo {
  id: 'A1' | 'A2' | 'B1' | 'B2' | 'C1';
  title: string;
  subtitle: string;
  tag: string;
  color: string;
  icon: string;
  desc: string;
}

export const STAGES: StageInfo[] = [
  { id: 'A1', title: 'স্তর ১: প্রারম্ভিক (Beginner)', subtitle: 'বর্ণমালা, কুশলাদি, পরিবার, সাধারণ বস্তু ও সংখ্যা', tag: 'A1 Beginner', color: '#1CB0F6', icon: '🌱', desc: 'ইংরেজি শেখার শুভ সূচনা' },
  { id: 'A2', title: 'স্তর ২: প্রাথমিক (Elementary)', subtitle: 'দৈনন্দিন রুটিন, খাবার, কেনাকাটা, সহজ প্রশ্ন ও যাতায়াত', tag: 'A2 Elementary', color: '#6366F1', icon: '🌿', desc: 'দৈনন্দিন জীবনের প্রয়োজনীয় ইংরেজি' },
  { id: 'B1', title: 'স্তর ৩: মধ্যবর্তী (Intermediate)', subtitle: 'অতীত ও ভবিষ্যৎ কাল, ভ্রমণ, ডাক্তার ও স্বাস্থ্য, অনুভূতি', tag: 'B1 Intermediate', color: '#FF9600', icon: '⚡', desc: 'ভ্রমণ ও আত্মবিশ্বাসের সাথে কথা বলা' },
  { id: 'B2', title: 'স্তর ৪: উচ্চ-মধ্যবর্তী (Upper-Intermediate)', subtitle: 'অফিস ও পেশাগত কাজ, মিটিং, ইমেইল, চুক্তি, মতামত ও বিতর্ক', tag: 'B2 Upper-Int', color: '#CE82FF', icon: '💼', desc: 'পেশাদার ও কর্পোরেট যোগাযোগের দক্ষতা' },
  { id: 'C1', title: 'স্তর ৫: দক্ষ ও পারদর্শী (Advanced Fluency)', subtitle: 'নেটিভ ইডিয়মস, ফ্রেজাল ভার্বস, একাডেমিক ও পাবলিক স্পিকিং', tag: 'C1 Advanced', color: '#FF4B4B', icon: '👑', desc: 'অনর্গল ও নিখুঁত ইংরেজি সাবলীলতা' },
];

export const DAILY_QUESTS = [
  { id: 'q_lessons', title: 'কমপক্ষে ২টি লেসন সম্পন্ন করুন', target: 2, xp: 30, gems: 10, icon: '🎯', type: 'lessons' },
  { id: 'q_words', title: 'শব্দকোষে ৫টি শব্দ শুনুন বা সেভ করুন', target: 5, xp: 20, gems: 5, icon: '📚', type: 'words' },
  { id: 'q_score', title: 'যেকোনো কুইজে ৮০%+ স্কোর করুন', target: 1, xp: 25, gems: 10, icon: '⚡', type: 'score' },
  { id: 'q_streak', title: 'আজকের স্ট্রিক বজায় রাখুন', target: 1, xp: 20, gems: 5, icon: '🔥', type: 'streak' },
];

export const STREAK_MILESTONES = [
  { days: 3, title: '৩ দিনের শিখা', xp: 50, gems: 15, badge: '🔥 ৩ দিন পূর্ণ', rewardName: 'স্ট্রিক শিল্ড (Streak Freeze) 🛡️' },
  { days: 7, title: '৭ দিনের যোদ্ধা', xp: 150, gems: 35, badge: '⚔️ ৭ দিন বিজয়ী', rewardName: 'গোল্ডেন ফ্লেম ব্যাজ 🏆' },
  { days: 14, title: '১৪ দিনের চ্যাম্পিয়ন', xp: 300, gems: 70, badge: '🌟 ১৪ দিনের তারা', rewardName: 'সুপার বুস্টার ও ট্রফি 👑' },
  { days: 30, title: '৩০ দিনের লিজেন্ড', xp: 800, gems: 150, badge: '💎 ১ মাস মাস্টার', rewardName: 'গ্র্যান্ড লিজেন্ডারি মুকুট 💎' },
];

export const ACHIEVEMENTS = [
  { id: 'first_lesson', title: 'প্রথম পদক্ষেপ', desc: '১টি লেসন সম্পূর্ণ করেছেন', icon: '🌱', req: 1, type: 'lessons' },
  { id: 'vocab_50', title: 'শব্দ অন্বেষী', desc: '৫০টি শব্দ অনুশীলন করেছেন', icon: '📖', req: 50, type: 'words' },
  { id: 'streak_3', title: 'টানা ৩ দিন', desc: '৩ দিন নিয়মিত অনুশীলন করেছেন', icon: '🔥', req: 3, type: 'streak' },
  { id: 'streak_7', title: 'সাপ্তাহিক যোদ্ধা', desc: 'টানা ৭ দিনের স্ট্রিক বজায় রেখেছেন', icon: '⚔️', req: 7, type: 'streak' },
  { id: 'perfect_score', title: 'নিখুঁত শতভাগ', desc: 'একটি লেসনে ১০০% নির্ভুল স্কোর করেছেন', icon: '💎', req: 1, type: 'perfect' },
  { id: 'sentence_50', title: 'বাক্য বিশারদ', desc: '৫০টি বাক্য অনুশীলন করেছেন', icon: '💬', req: 50, type: 'sentences' },
  { id: 'xp_500', title: 'জ্ঞান সমুদ্র', desc: '৫০০ XP অর্জন করেছেন', icon: '⚡', req: 500, type: 'xp' },
  { id: 'exam_pass', title: 'পরীক্ষায় উত্তীর্ণ', desc: 'পরীক্ষায় ৭০%+ পেয়ে পাস করেছেন', icon: '🎓', req: 1, type: 'exam' },
];

// Helpers
const R = (id: string, bn: string, en: string): Question => ({
  id,
  type: 'reorder',
  prompt: `ইংরেজিতে সাজান: ${bn}`,
  words: en.split(' '),
  answer: en.split(' '),
  hint: `✔ সঠিক বাক্য: ${en}`
});

const M = (id: string, prompt: string, options: string[], answer: string, hint: string): Question => ({
  id,
  type: 'mcq',
  prompt,
  options,
  answer,
  hint
});

const L = (id: string, audioText: string, options: string[], answer: string, hint: string): Question => ({
  id,
  type: 'listening',
  prompt: 'শুনুন এবং সঠিক ইংরেজি বাক্যটি বেছে নিন:',
  audioText,
  options,
  answer,
  hint
});

// Build Core Stage Modules (Beginner A1 -> Advanced C1)
export const CORE_MODULES: CurriculumModule[] = [
  // ================= STAGE 1: BEGINNER (A1) =================
  {
    id: 'mod_1',
    stageId: 'A1',
    stageName: 'স্তর ১: প্রারম্ভিক',
    title: '১. মৌলিক ও অভিবাদন (Basics & Greetings)',
    desc: 'দৈনন্দিন অভিবাদন, প্রাথমিক কুশলাদি ও নিজের পরিচয়',
    icon: '👋',
    bg: 'from-sky-500 to-sky-600',
    lessons: [
      {
        id: 'l1_1',
        title: 'সাধারণ কুশলাদি (Basic Greetings)',
        xp: 20,
        questions: [
          M('q1_1', 'Choose the correct meaning of "Hello, how are you?"', ['হ্যালো, আপনি কেমন আছেন?', 'শুভ সকাল, কোথায় যাচ্ছেন?', 'আপনার নাম কি?', 'আমি ভালো আছি!'], 'হ্যালো, আপনি কেমন আছেন?', '"How are you?" এর বাংলা হলো "আপনি কেমন আছেন?"'),
          R('q1_2', 'শুভ সকাল, আপনার সাথে দেখা হয়ে ভালো লাগল।', 'Good morning, nice to meet you.'),
          L('q1_3', 'See you tomorrow', ['See you tomorrow', 'Good night friend', 'How is it going', 'Welcome to my office'], 'See you tomorrow', '"See you tomorrow" শব্দের অর্থ "আগামীকাল আবার দেখা হবে"।'),
          {
            id: 'q1_4',
            type: 'matching',
            prompt: 'ইংরেজি শব্দের সাথে বাংলা অর্থ মেলান:',
            pairs: [
              { en: 'Welcome', bn: 'স্বাগতম' },
              { en: 'Thank you', bn: 'ধন্যবাদ' },
              { en: 'Goodbye', bn: 'বিদায়' },
              { en: 'Please', bn: 'দয়া করে' }
            ]
          }
        ]
      },
      {
        id: 'l1_2',
        title: 'পরিবার ও পরিচয় (Family & Intro)',
        xp: 25,
        questions: [
          M('q1_5', 'Choose the correct translation for "আমি একজন শিক্ষার্থী":', ['I am a student.', 'I am a teacher.', 'He is a student.', 'We are students.'], 'I am a student.', 'Student = শিক্ষার্থী / ছাত্র-ছাত্রী।'),
          R('q1_6', 'আমার পরিবারে চারজন সদস্য আছে।', 'There are four members in my family.'),
          M('q1_7', '"Father" এবং "Mother" এর বাংলা অর্থ কী?', ['বাবা এবং মা', 'ভাই এবং বোন', 'দাদা এবং দাদি', 'চাচা এবং চাচি'], 'বাবা এবং মা', 'Father = বাবা, Mother = মা'),
          L('q1_8', 'Nice to meet you', ['Nice to meet you', 'How old are you', 'Where do you live', 'Have a nice day'], 'Nice to meet you', 'Nice to meet you = আপনার সাথে দেখা হয়ে ভালো লাগল।')
        ]
      }
    ]
  },
  {
    id: 'mod_2',
    stageId: 'A1',
    stageName: 'স্তর ১: প্রারম্ভিক',
    title: '২. প্রয়োজনীয় শব্দাবলী ও সংখ্যা (Numbers & Objects)',
    desc: '১ থেকে ১০০ গণনা, সাধারণ গৃহস্থালি জিনিসপত্র ও রঙ',
    icon: '🔢',
    bg: 'from-blue-500 to-cyan-600',
    lessons: [
      {
        id: 'l2_1',
        title: 'সংখ্যা ও পরিমাণ (Numbers & Quantity)',
        xp: 20,
        questions: [
          M('q2_1', '"Twenty-five" সংখ্যাটি বাংলায় কত?', ['পঁচিশ', 'পঁয়ত্রিশ', 'পনেরো', 'বিশ'], 'পঁচিশ', 'Twenty = ২০, Five = ৫ -> ২৫'),
          R('q2_2', 'আমার কাছে তিনটি বই আছে।', 'I have three books.'),
          {
            id: 'q2_3',
            type: 'matching',
            prompt: 'রং ও অর্থের সঠিক জোড়া মেলান:',
            pairs: [
              { en: 'Red', bn: 'লাল' },
              { en: 'Green', bn: 'সবুজ' },
              { en: 'Blue', bn: 'নীল' },
              { en: 'Yellow', bn: 'হলুদ' }
            ]
          },
          M('q2_4', '"One hundred" এর বাংলা কী?', ['একশত / একশো', 'এক হাজার', 'দশ', 'পঁচিশ'], 'একশত / একশো', 'Hundred = একশো')
        ]
      },
      {
        id: 'l2_2',
        title: 'সহজ বাক্য গঠন (Simple am/is/are)',
        xp: 25,
        questions: [
          R('q2_5', 'তিনি একজন সৎ মানুষ।', 'He is an honest man.'),
          R('q2_6', 'আমরা একসাথে আছি।', 'We are together.'),
          M('q2_7', '"They are happy" এর সঠিক বাংলা অর্থ কী?', ['তারা সুখী / খুশি।', 'তারা দুঃখী।', 'তারা খেলছে।', 'সে খুশি ছিল।'], 'তারা সুখী / খুশি।', 'Happy = খুশি বা সুখী'),
          L('q2_8', 'This is a beautiful flower.', ['This is a beautiful flower.', 'That is a big house.', 'She has a blue pen.', 'We love this garden.'], 'This is a beautiful flower.', 'This is a beautiful flower = এটি একটি সুন্দর ফুল।')
        ]
      }
    ]
  },
  {
    id: 'mod_3',
    stageId: 'A1',
    stageName: 'স্তর ১: প্রারম্ভিক',
    title: '৩. প্রারম্ভিক মূল্যায়ন পরীক্ষা (Checkpoint A1)',
    desc: 'লেভেল ১ এর সকল বিষয়বস্তুর সমন্বিত পরীক্ষা ও সার্টিফিকেট পয়েন্ট',
    icon: '🎯',
    bg: 'from-emerald-500 to-teal-600',
    lessons: [
      {
        id: 'l3_check',
        title: 'A1 চেকপয়েন্ট কুইজ (Checkpoint Exam)',
        xp: 40,
        isExam: true,
        questions: [
          M('q3_1', '"Good evening" কখন বলা হয়?', ['সন্ধ্যায় অভিবাদন জানাতে', 'সকালে ঘুম থেকে উঠে', 'বিদায় নেওয়ার সময়', 'দুপুরে খাবার সময়'], 'সন্ধ্যায় অভিবাদন জানাতে', 'Evening = সন্ধ্যা'),
          R('q3_2', 'আমি প্রতিদিন সকালে চা পান করি।', 'I drink tea every morning.'),
          L('q3_3', 'What is your name?', ['What is your name?', 'Where is your home?', 'How old are you?', 'Who is your friend?'], 'What is your name?', 'What is your name? = আপনার নাম কী?'),
          R('q3_4', 'সে আমার সবচেয়ে ভালো বন্ধু।', 'He is my best friend.'),
          M('q3_5', '"Thank you very much" এর বাংলা অর্থ কী?', ['আপনাকে অনেক ধন্যবাদ', 'আপনাকে স্বাগতম', 'মাফ করবেন', 'কাল দেখা হবে'], 'আপনাকে অনেক ধন্যবাদ', 'Thank you very much = অনেক ধন্যবাদ')
        ]
      }
    ]
  },

  // ================= STAGE 2: ELEMENTARY (A2) =================
  {
    id: 'mod_4',
    stageId: 'A2',
    stageName: 'স্তর ২: প্রাথমিক',
    title: '৪. খাবার ও ডাইনিং (Food & Dining)',
    desc: 'রেস্তোরাঁয় খাবার অর্ডার, খাবারের স্বাদ ও ভদ্র কথোপকথন',
    icon: '🍎',
    bg: 'from-amber-500 to-orange-600',
    lessons: [
      {
        id: 'l4_1',
        title: 'খাবার অর্ডার ও মেনু (Ordering Food)',
        xp: 25,
        questions: [
          M('q4_1', 'Translate: "I would like to order a glass of water."', ['আমি এক গ্লাস পানি অর্ডার করতে চাই।', 'আমি চা পছন্দ করি।', 'পানি অনেক ঠাণ্ডা।', 'আমি এক গ্লাস দুধ চাই।'], 'আমি এক গ্লাস পানি অর্ডার করতে চাই।', '"I would like to..." কোনো কিছু নম্রভাবে চাওয়ার বাক্য।'),
          R('q4_2', 'দয়া করে আমাকে মেনুটা দিন।', 'Please give me the menu.'),
          {
            id: 'q4_3',
            type: 'matching',
            prompt: 'খাবারের নামের সাথে অর্থ মেলান:',
            pairs: [
              { en: 'Rice', bn: 'ভাত' },
              { en: 'Fish', bn: 'মাছ' },
              { en: 'Milk', bn: 'দুধ' },
              { en: 'Bread', bn: 'রুটি' }
            ]
          },
          L('q4_4', 'The food is very delicious.', ['The food is very delicious.', 'The water is cold.', 'I want some tea.', 'Bring the bill please.'], 'The food is very delicious.', 'Delicious = সুস্বাদু')
        ]
      },
      {
        id: 'l4_2',
        title: 'বিল পরিশোধ ও ধন্যবাদ (Paying Bill)',
        xp: 25,
        questions: [
          R('q4_5', 'আমরা কি বিলটা পেতে পারি?', 'Could we have the bill?'),
          M('q4_6', '"Keep the change" কথাটির অর্থ কী?', ['বাকি খুচরা টাকাটা রেখে দিন', 'আমাকে পরিবর্তন দিন', 'টাকা শেষ হয়ে গেছে', 'বিল বেশি এসেছে'], 'বাকি খুচরা টাকাটা রেখে দিন', 'Change = ভাঙতি / খুচরা টাকা'),
          R('q4_7', 'আমি নগদ টাকা দিতে চাই।', 'I want to pay cash.')
        ]
      }
    ]
  },
  {
    id: 'mod_5',
    stageId: 'A2',
    stageName: 'স্তর ২: প্রাথমিক',
    title: '৫. কেনাকাটা ও দামদর (Shopping & Prices)',
    desc: 'দোকানে কাপড় কেনা, সাইজ পছন্দ ও মূল্য জিজ্ঞাসা',
    icon: '🛍️',
    bg: 'from-purple-500 to-indigo-600',
    lessons: [
      {
        id: 'l5_1',
        title: 'দোকানে কথা বলা (In the Shop)',
        xp: 30,
        questions: [
          M('q5_1', 'How to ask price in English politely?', ['How much does this cost?', 'Where is your shop?', 'What is your name?', 'I don’t want this.'], 'How much does this cost?', '"How much does this cost?" = এটার দাম কত?'),
          R('q5_2', 'এটা কি বড় সাইজে আছে?', 'Do you have this in a bigger size?'),
          M('q5_3', '"It is too expensive" এর অর্থ কী?', ['এটা অনেক দামি।', 'এটা খুব সস্তা।', 'এটা ভালো নয়।', 'এটা খুব ছোট।'], 'এটা অনেক দামি।', 'Expensive = দামি / ব্যয়বহুল'),
          L('q5_4', 'Can I pay by card?', ['Can I pay by card?', 'Do you have cash?', 'Where is the bank?', 'I like this shirt.'], 'Can I pay by card?', 'Can I pay by card? = আমি কি কার্ডে টাকা দিতে পারি?')
        ]
      }
    ]
  },
  {
    id: 'mod_6',
    stageId: 'A2',
    stageName: 'স্তর ২: প্রাথমিক',
    title: '৬. প্রাথমিক স্তর সমাপ্তি পরীক্ষা (Checkpoint A2)',
    desc: 'খাবার, কেনাকাটা ও দৈনন্দিন রুটিনের সমন্বিত মূল্যায়ন',
    icon: '🏆',
    bg: 'from-blue-600 to-indigo-700',
    lessons: [
      {
        id: 'l6_check',
        title: 'A2 চেকপয়েন্ট কুইজ (Checkpoint Exam)',
        xp: 45,
        isExam: true,
        questions: [
          R('q6_1', 'আমি বাসে করে কাজে যাই।', 'I go to work by bus.'),
          M('q6_2', '"I usually wake up at six" এর অর্থ কী?', ['আমি সাধারণত ছয়টায় ঘুম থেকে উঠি।', 'আমি ছয়টায় বাড়ি ফিরি।', 'আমি ছয় ঘণ্টা ঘুমাই।', 'আমার ছয়টি ঘড়ি আছে।'], 'আমি সাধারণত ছয়টায় ঘুম থেকে উঠি।', 'Wake up = ঘুম থেকে ওঠা'),
          L('q6_3', 'How much is this shirt?', ['How much is this shirt?', 'Where is my shirt?', 'I like this color.', 'This is too small.'], 'How much is this shirt?', 'How much is this shirt? = এই শার্টটির দাম কত?'),
          R('q6_4', 'মোড়ে বামে ঘুরুন।', 'Turn left at the corner.'),
          M('q6_5', '"Could you give me a discount?" কথাটি কখন বলা হয়?', ['দোকানে দাম কমানোর অনুরোধ করতে', 'খাবার অর্ডার করার সময়', 'বিদায় নেওয়ার সময়', 'বাসে ওঠার সময়'], 'দোকানে দাম কমানোর অনুরোধ করতে', 'Discount = মূল্যছাড়')
        ]
      }
    ]
  },

  // ================= STAGE 3: INTERMEDIATE (B1) =================
  {
    id: 'mod_7',
    stageId: 'B1',
    stageName: 'স্তর ৩: মধ্যবর্তী',
    title: '৭. অতীত ও ভবিষ্যৎ কাল (Past & Future Tense)',
    desc: 'গতকাল কী ঘটেছিল এবং আগামীকাল কী ঘটবে তা সুন্দরভাবে বলা',
    icon: '🕰️',
    bg: 'from-amber-600 to-red-600',
    lessons: [
      {
        id: 'l7_1',
        title: 'অতীত কালের কথা (Past Events)',
        xp: 30,
        questions: [
          R('q7_1', 'আমি গতকাল বাজারে গিয়েছিলাম।', 'I went to the market yesterday.'),
          M('q7_2', '"She wrote a letter" এর অর্থ কী?', ['সে একটি চিঠি লিখেছিল।', 'সে চিঠি পড়ছে।', 'সে চিঠি লিখবে।', 'চিঠি হারিয়ে গেছে।'], 'সে একটি চিঠি লিখেছিল।', 'Wrote = লিখেছিল (write এর অতীত রূপ)'),
          R('q7_3', 'আমি আগামীকাল তোমাকে ফোন করব।', 'I will call you tomorrow.'),
          L('q7_4', 'We visited our grandparents last Friday.', ['We visited our grandparents last Friday.', 'We will go to school tomorrow.', 'They are playing outside.', 'He bought a new car yesterday.'], 'We visited our grandparents last Friday.', 'Visited = দেখতে গিয়েছিলাম / দেখা করেছিলাম')
        ]
      }
    ]
  },
  {
    id: 'mod_8',
    stageId: 'B1',
    stageName: 'স্তর ৩: মধ্যবর্তী',
    title: '৮. ভ্রমণ ও হোটেল বুকিং (Travel & Booking)',
    desc: 'বিমানবন্দর, টিকিট কাটা, হোটেল রুম বুকিং ও পর্যটন',
    icon: '✈️',
    bg: 'from-cyan-600 to-blue-700',
    lessons: [
      {
        id: 'l8_1',
        title: 'ভ্রমণ প্রস্তুতি ও হোটেল (Hotel Booking)',
        xp: 35,
        questions: [
          R('q8_1', 'আমি একটি রুম বুক করতে চাই।', 'I would like to book a room.'),
          M('q8_2', '"What time does the train leave?" এর অর্থ কী?', ['ট্রেন কয়টায় ছাড়ে?', 'ট্রেন কখন পৌঁছাবে?', 'ট্রেন কোথায় থামবে?', 'ট্রেনের ভাড়া কত?'], 'ট্রেন কয়টায় ছাড়ে?', 'Leave = ছেড়ে যাওয়া বা প্রস্থান করা'),
          R('q8_3', 'আমি আমার পাসপোর্ট হারিয়ে ফেলেছি।', 'I have lost my passport.'),
          L('q8_4', 'Your room number is 405.', ['Your room number is 405.', 'Breakfast is on the fourth floor.', 'Take the elevator to the left.', 'Checkout time is eleven.'], 'Your room number is 405.', 'Room number = কক্ষ নম্বর')
        ]
      }
    ]
  },
  {
    id: 'mod_9',
    stageId: 'B1',
    stageName: 'স্তর ৩: মধ্যবর্তী',
    title: '৯. স্বাস্থ্য, ডাক্তার ও জরুরি অবস্থা (Health & Medical)',
    desc: 'ডাক্তারকে শারীরিক উপসর্গ বলা ও ওষুধের নিয়ম জানা',
    icon: '🏥',
    bg: 'from-rose-500 to-pink-600',
    lessons: [
      {
        id: 'l9_1',
        title: 'ডাক্তারের পরামর্শ (At the Doctor)',
        xp: 35,
        questions: [
          R('q9_1', 'আমার তীব্র মাথাব্যথা করছে।', 'I have a severe headache.'),
          M('q9_2', '"Take this medicine twice a day" এর অর্থ কী?', ['এই ওষুধ দিনে দুইবার খাবেন।', 'এই ওষুধ রাতে খাবেন।', 'দুই দিন পর আসবেন।', 'ওষুধ খাওয়ার দরকার নেই।'], 'এই ওষুধ দিনে দুইবার খাবেন।', 'Twice a day = দিনে দুইবার'),
          R('q9_3', 'দয়া করে দ্রুত অ্যাম্বুলেন্স ডাকুন।', 'Please call an ambulance immediately.'),
          L('q9_4', 'You should drink more water.', ['You should drink more water.', 'Take this medicine now.', 'I need to see a doctor.', 'Rest for two days.'], 'You should drink more water.', 'You should = আপনার উচিত')
        ]
      }
    ]
  },
  {
    id: 'mod_10',
    stageId: 'B1',
    stageName: 'স্তর ৩: মধ্যবর্তী',
    title: '১০. মধ্যবর্তী স্তর সমাপ্তি পরীক্ষা (Checkpoint B1)',
    desc: 'কাল, ভ্রমণ, স্বাস্থ্য ও আত্মবিশ্বাসী কথোপকথন পরীক্ষা',
    icon: '🌟',
    bg: 'from-indigo-600 to-violet-700',
    lessons: [
      {
        id: 'l10_check',
        title: 'B1 চেকপয়েন্ট কুইজ (Checkpoint Exam)',
        xp: 50,
        isExam: true,
        questions: [
          R('q10_1', 'আমার মতে এটা একটা ভালো পরিকল্পনা।', 'In my opinion this is a good plan.'),
          M('q10_2', '"It depends on the situation" এর বাংলা কী?', ['এটা পরিস্থিতির উপর নির্ভর করে।', 'আমি সম্পূর্ণ নিশ্চিত।', 'কোনো সমস্যা নেই।', 'সময়মতো পৌঁছাব।'], 'এটা পরিস্থিতির উপর নির্ভর করে।', 'Depends on = নির্ভর করে'),
          L('q10_3', 'I hope everything goes well.', ['I hope everything goes well.', 'I do not agree with you.', 'That sounds interesting.', 'I will call you later.'], 'I hope everything goes well.', 'I hope = আমি আশা করি'),
          R('q10_4', 'আমরা সময়মতো বিমানবন্দরে পৌঁছেছিলাম।', 'We arrived at the airport on time.'),
          M('q10_5', '"Get well soon" কখন বলা হয়?', ['কেউ অসুস্থ হলে আরোগ্য কামনায়', 'কারো জন্মদিনে', 'বিদায় নেওয়ার সময়', 'বিজয় উদযাপনে'], 'কেউ অসুস্থ হলে আরোগ্য কামনায়', 'Get well soon = দ্রুত সুস্থ হয়ে উঠুন')
        ]
      }
    ]
  },

  // ================= STAGE 4: UPPER-INTERMEDIATE (B2) =================
  {
    id: 'mod_11',
    stageId: 'B2',
    stageName: 'স্তর ৪: উচ্চ-মধ্যবর্তী',
    title: '১১. অফিস ও কর্পোরেট ইমেইল (Office & Professional Writing)',
    desc: 'পেশাদার ইমেইল লেখা, মিটিংয়ের শিডিউল ও প্রতিবেদন',
    icon: '💼',
    bg: 'from-slate-600 to-slate-800',
    lessons: [
      {
        id: 'l11_1',
        title: 'অফিস মিটিং ও ইমেইল (Professional Email)',
        xp: 40,
        questions: [
          M('q11_1', 'ইমেইলের সাথে কোনো ফাইল যোগ করার সময় কোন বাক্যটি ব্যবহার করবেন?', ['Please find the attached file.', 'I lost the file.', 'The file is closed.', 'Send the file tomorrow.'], 'Please find the attached file.', 'Attached file = সংযুক্ত ফাইল'),
          R('q11_2', 'আমি একটি জরুরি মিটিং ঠিক করতে চাই।', 'I would like to schedule an urgent meeting.'),
          L('q11_3', 'The deadline is next Monday.', ['The deadline is next Monday.', 'The meeting is canceled.', 'Please send the proposal.', 'We will discuss this tomorrow.'], 'The deadline is next Monday.', 'Deadline = নির্দিষ্ট শেষ সময়সীমা'),
          R('q11_4', 'আপনার মূল্যবান মতামতের জন্য অনেক ধন্যবাদ।', 'Thank you for your valuable feedback.')
        ]
      }
    ]
  },
  {
    id: 'mod_12',
    stageId: 'B2',
    stageName: 'স্তর ৪: উচ্চ-মধ্যবর্তী',
    title: '১২. চাকরি ইন্টারভিউ ও ক্যারিয়ার (Job Interview & Career)',
    desc: 'নিজের শক্তি তুলে ধরা, অভিজ্ঞতা বর্ণনা ও বেতন আলোচনা',
    icon: '🎯',
    bg: 'from-emerald-600 to-green-700',
    lessons: [
      {
        id: 'l12_1',
        title: 'ইন্টারভিউ কৌশল (Interview Responses)',
        xp: 40,
        questions: [
          M('q12_1', 'How to politely state experience in an interview?', ['I have three years of experience in project management.', 'I have no experience at all.', 'I don’t like projects.', 'I left my job yesterday.'], 'I have three years of experience in project management.', 'Experience = অভিজ্ঞতা'),
          R('q12_2', 'আমি চাপের মধ্যেও চমৎকার কাজ করতে পারি।', 'I can work very well under pressure.'),
          L('q12_3', 'Why do you want to join our organization?', ['Why do you want to join our organization?', 'What is your previous salary?', 'When can you start working?', 'Where is your resume?'], 'Why do you want to join our organization?', 'Organization = প্রতিষ্ঠান বা সংস্থা')
        ]
      }
    ]
  },
  {
    id: 'mod_13',
    stageId: 'B2',
    stageName: 'স্তর ৪: উচ্চ-মধ্যবর্তী',
    title: '১৩. উচ্চ-মধ্যবর্তী সমাপ্তি পরীক্ষা (Checkpoint B2)',
    desc: 'পেশাদার যোগাযোগ, মতামত যুক্তি ও ব্যবসায়িক ইংরেজি পরীক্ষা',
    icon: '🎖️',
    bg: 'from-blue-700 to-slate-900',
    lessons: [
      {
        id: 'l13_check',
        title: 'B2 চেকপয়েন্ট কুইজ (Checkpoint Exam)',
        xp: 55,
        isExam: true,
        questions: [
          R('q13_1', 'মান বজায় রেখে আমাদের অবশ্যই কাজ শেষ করতে হবে।', 'We must finish the work without compromising quality.'),
          M('q13_2', '"I strongly advocate for this solution" এর অর্থ কী?', ['আমি এই সমাধানের পক্ষে জোরালো সমর্থন জানাচ্ছি।', 'আমি সমাধানটি মানি না।', 'সমাধানটি ভুল।', 'আমার কোনো মত নেই।'], 'আমি এই সমাধানের পক্ষে জোরালো সমর্থন জানাচ্ছি।', 'Advocate = জোরালো সমর্থন করা'),
          L('q13_3', 'We achieved eighty percent of our quarterly target.', ['We achieved eighty percent of our quarterly target.', 'Our budget was rejected yesterday.', 'The meeting starts at two.', 'Please email the spreadsheet.'], 'We achieved eighty percent of our quarterly target.', 'Target = লক্ষ্যমাত্রা'),
          R('q13_4', 'আমি একটি বিকল্প কর্মপদ্ধতি প্রস্তাব করতে চাই।', 'I would like to propose an alternative approach.')
        ]
      }
    ]
  },

  // ================= STAGE 5: ADVANCED (C1) =================
  {
    id: 'mod_14',
    stageId: 'C1',
    stageName: 'স্তর ৫: পারদর্শী',
    title: '১৪. নেটিভ ইডিয়ম ও ফ্রেজাল ভার্বস (Native Idioms & Phrasals)',
    desc: 'নেটিভ বক্তাদের মতো প্রাকৃতিক ও সাবলীল বাগধারা প্রয়োগ',
    icon: '🚀',
    bg: 'from-rose-600 to-red-700',
    lessons: [
      {
        id: 'l14_1',
        title: 'নেটিভ বাগধারা (Mastering Idioms)',
        xp: 45,
        questions: [
          M('q14_1', 'What does "Piece of cake" mean in conversation?', ['এই কাজটি অত্যন্ত সহজ!', 'কাজটি কেকের মতো মিষ্টি।', 'কাজটি করা অসম্ভব।', 'কাজটিতে অনেক সময় লাগবে।'], 'এই কাজটি অত্যন্ত সহজ!', '"Piece of cake" একটি Idiom যার অর্থ অত্যন্ত সহজ কাজ।'),
          M('q14_2', '"Hit the books" কথাটির সঠিক অর্থ কী?', ['মনোযোগ দিয়ে পড়তে বসা', 'বই ছুড়ে ফেলা', 'বই কেনা', 'বইয়ের ক্ষতি করা'], 'মনোযোগ দিয়ে পড়তে বসা', 'Hit the books = পড়াশোনা শুরু করা'),
          R('q14_3', 'চলুন আজকের মতো কাজ শেষ করি।', 'Let us call it a day.'),
          L('q14_4', 'Practice makes perfect.', ['Practice makes perfect.', 'Time is money.', 'Better late than never.', 'Actions speak louder than words.'], 'Practice makes perfect.', 'Practice makes perfect = অনুশীলনেই দক্ষতা বাড়ে।')
        ]
      }
    ]
  },
  {
    id: 'mod_15',
    stageId: 'C1',
    stageName: 'স্তর ৫: পারদর্শী',
    title: '১৫. গ্র্যান্ড মাস্টার ফ্লুয়েন্সি পরীক্ষা (Grand Master C1 Exam)',
    desc: 'ইংরেজি ভাষার পূর্ণাঙ্গ দক্ষতা ও পারদর্শিতা যাচাই',
    icon: '👑',
    bg: 'from-amber-500 via-rose-500 to-indigo-600',
    lessons: [
      {
        id: 'l15_grand',
        title: 'C1 গ্র্যান্ড মাস্টার সার্টিফিকেশন পরীক্ষা',
        xp: 70,
        isExam: true,
        questions: [
          R('q15_1', 'আপনি যত বেশি পড়বেন আপনার দৃষ্টিভঙ্গি তত বেশি প্রসারিত হবে।', 'The more you read the broader your perspective becomes.'),
          M('q15_2', '"Ubiquitous" শব্দটির সবচেয়ে নির্ভুল অর্থ কোনটি?', ['সর্বব্যাপী বা সর্বত্র বিদ্যমান', 'খুবই বিরল', 'অত্যন্ত বিপদজনক', 'স্বাদহীন'], 'সর্বব্যাপী বা সর্বত্র বিদ্যমান', 'Ubiquitous = সর্বত্র বিদ্যমান'),
          L('q15_3', 'Actions speak much louder than words.', ['Actions speak much louder than words.', 'Do not judge a book by its cover.', 'Time flies so quickly.', 'Every cloud has a silver lining.'], 'Actions speak much louder than words.', 'কথার চেয়ে কাজের জোর বেশি'),
          R('q15_4', 'ধৈর্য এবং নিষ্ঠা থাকলে সাবলীল ইংরেজি আপনার নাগালের মধ্যেই।', 'With patience and dedication fluency is within your reach.'),
          M('q15_5', '"Resilient" ব্যক্তির বৈশিষ্ট্য কী?', ['প্রতিকূল পরিস্থিতি কাটিয়ে ঘুরে দাঁড়াতে সক্ষম', 'খুব অহংকারী', 'অলস ও কর্মবিমুখ', 'সহজে আশা ছেড়ে দেয়'], 'প্রতিকূল পরিস্থিতি কাটিয়ে ঘুরে দাঁড়াতে সক্ষম', 'Resilient = প্রতিকূলতায় সহনশীল ও ঘুরে দাঁড়াতে সক্ষম')
        ]
      }
    ]
  }
];

// Helper to auto-generate Word Modules (teaching every word in chunked lessons)
const WORDS_PER_LESSON = 12;
const LESSONS_PER_WORD_MODULE = 8;
const bnNum = (n: number) => String(n).replace(/\d/g, d => '০১২৩৪৫৬৭৮৯'[parseInt(d, 10)]);

export const WORD_MODULES: CurriculumModule[] = [];
{
  const nLessons = Math.ceil(ALL_WORDS_DATABASE.length / WORDS_PER_LESSON);
  for (let wIdx = 0; wIdx < nLessons; wIdx++) {
    const mi = Math.floor(wIdx / LESSONS_PER_WORD_MODULE) + 1;
    const li = (wIdx % LESSONS_PER_WORD_MODULE) + 1;
    const words = ALL_WORDS_DATABASE.slice(wIdx * WORDS_PER_LESSON, (wIdx + 1) * WORDS_PER_LESSON);
    if (!WORD_MODULES[mi - 1]) {
      WORD_MODULES[mi - 1] = {
        id: `wmod_${mi}`,
        title: '',
        desc: '',
        kind: 'word',
        kindNo: mi,
        icon: '📚',
        lessons: [],
        from: words[0]?.id || 1,
        to: words[words.length - 1]?.id || 12
      };
    }
    const mod = WORD_MODULES[mi - 1];
    if (words.length > 0) {
      mod.to = words[words.length - 1].id;
    }

    // Build questions for this lesson
    const lid = `wmod_${mi}_l${li}`;
    const qs: Question[] = [];

    // Matching question for first 4 words
    if (words.length >= 4) {
      qs.push({
        id: `${lid}_m4`,
        type: 'matching',
        prompt: 'ইংরেজি শব্দের সাথে বাংলা অর্থ মেলান:',
        pairs: words.slice(0, 4).map(w => ({ en: w.word, bn: w.bn }))
      });
    }

    // MCQ questions
    words.slice(0, 4).forEach((w, idx) => {
      const otherWords = ALL_WORDS_DATABASE.filter(x => x.id !== w.id && x.bn !== w.bn);
      const opts = [w.bn];
      for (let j = 1; j <= 3; j++) {
        const dummy = otherWords[(w.id * 7 + j * 13) % otherWords.length];
        if (dummy && !opts.includes(dummy.bn)) opts.push(dummy.bn);
      }
      opts.sort(() => (w.id % 2 === 0 ? 1 : -1));
      qs.push({
        id: `${lid}_mcq_${idx}`,
        type: 'mcq',
        prompt: `"${w.word}" এর সঠিক বাংলা অর্থ কী?`,
        questionEn: w.word,
        options: opts,
        answer: w.bn,
        hint: `${w.word} = ${w.bn} (${w.category})`
      });
    });

    // Listening question
    if (words.length > 4) {
      const lw = words[4];
      const otherWords = ALL_WORDS_DATABASE.filter(x => x.id !== lw.id);
      const opts = [lw.word];
      for (let j = 1; j <= 3; j++) {
        const dummy = otherWords[(lw.id * 11 + j * 17) % otherWords.length];
        if (dummy && !opts.includes(dummy.word)) opts.push(dummy.word);
      }
      opts.sort(() => -1);
      qs.push({
        id: `${lid}_listen`,
        type: 'listening',
        prompt: 'মনোযোগ দিয়ে শুনুন এবং সঠিক ইংরেজি শব্দটি নির্বাচন করুন:',
        audioText: lw.word,
        options: opts,
        answer: lw.word,
        hint: `${lw.word} = ${lw.bn}`
      });
    }

    mod.lessons.push({
      id: lid,
      count: words.length,
      title: `শব্দ ${bnNum(words[0]?.id || 1)}–${bnNum(words[words.length - 1]?.id || 12)}`,
      xp: 20,
      questions: qs
    });
  }

  WORD_MODULES.forEach(m => {
    const cats: Record<string, number> = {};
    ALL_WORDS_DATABASE.filter(w => w.id >= (m.from || 1) && w.id <= (m.to || 12)).forEach(w => {
      cats[w.category] = (cats[w.category] || 0) + 1;
    });
    const top = Object.entries(cats).sort((a, b) => b[1] - a[1]).slice(0, 3).map(x => x[0]).join(', ');
    m.title = `${bnNum(m.kindNo || 1)}. শব্দ মডিউল (শব্দ ${bnNum(m.from || 1)}–${bnNum(m.to || 12)})`;
    m.desc = `${bnNum(m.lessons.length)}টি লেসন · ${top}`;
  });
}

// Helper to auto-generate Sentence Modules (teaching all 1060 sentences in chunked lessons)
const SENTS_PER_LESSON = 6;
const LESSONS_PER_SENT_MODULE = 8;

export const SENT_MODULES: CurriculumModule[] = [];
{
  const nLessons = Math.ceil(SENTENCE_BANK.length / SENTS_PER_LESSON);
  for (let lIdx = 0; lIdx < nLessons; lIdx++) {
    const mi = Math.floor(lIdx / LESSONS_PER_SENT_MODULE) + 1;
    const li = (lIdx % LESSONS_PER_SENT_MODULE) + 1;
    const sents = SENTENCE_BANK.slice(lIdx * SENTS_PER_LESSON, (lIdx + 1) * SENTS_PER_LESSON);
    if (!SENT_MODULES[mi - 1]) {
      SENT_MODULES[mi - 1] = {
        id: `smod_${mi}`,
        title: '',
        desc: '',
        kind: 'sent',
        kindNo: mi,
        icon: '💬',
        lessons: [],
        from: sents[0]?.id || 1,
        to: sents[sents.length - 1]?.id || 6
      };
    }
    const mod = SENT_MODULES[mi - 1];
    if (sents.length > 0) {
      mod.to = sents[sents.length - 1].id;
    }

    const lid = `smod_${mi}_l${li}`;
    const qs: Question[] = [];

    sents.forEach((x, i) => {
      if (x.en.split(' ').length <= 8) {
        qs.push(R(`${lid}_r${i}`, x.bn, x.en));
      } else {
        const pool = SENTENCE_BANK.filter(y => y.id !== x.id && y.bn !== x.bn);
        const picks: string[] = [];
        for (let j = 0; j < pool.length && picks.length < 3; j++) {
          const y = pool[(x.id * 7 + j * 13) % pool.length];
          if (!picks.includes(y.bn)) picks.push(y.bn);
        }
        const opts = [...picks];
        opts.splice(x.id % 4, 0, x.bn);
        qs.push(M(`${lid}_m${i}`, `"${x.en}" — বাংলা অর্থ কী?`, opts, x.bn, `${x.en} = ${x.bn}`));
      }

      if (i % 2 === 1) {
        const pool = SENTENCE_BANK.filter(y => y.id !== x.id && y.en !== x.en);
        const picks: string[] = [];
        for (let j = 0; j < pool.length && picks.length < 3; j++) {
          const y = pool[(x.id * 11 + j * 17) % pool.length];
          if (!picks.includes(y.en)) picks.push(y.en);
        }
        const opts = [...picks];
        opts.splice((x.id + 1) % 4, 0, x.en);
        qs.push(L(`${lid}_h${i}`, x.en, opts, x.en, `${x.en} = ${x.bn}`));
      }
    });

    mod.lessons.push({
      id: lid,
      count: sents.length,
      title: `বাক্য ${bnNum(sents[0]?.id || 1)}–${bnNum(sents[sents.length - 1]?.id || 6)}`,
      xp: 25,
      questions: qs
    });
  }

  SENT_MODULES.forEach(m => {
    const cats = Array.from(new Set(SENTENCE_BANK.filter(x => x.id >= (m.from || 1) && x.id <= (m.to || 6)).map(x => x.category))).slice(0, 3).join(', ');
    m.title = `${bnNum(m.kindNo || 1)}. বাক্য মডিউল (বাক্য ${bnNum(m.from || 1)}–${bnNum(m.to || 6)})`;
    m.desc = `${bnNum(m.lessons.length)}টি লেসন · ${cats}`;
  });
}

CORE_MODULES.forEach((m, i) => {
  m.kind = 'core';
  m.kindNo = i + 1;
});

export const ALL_CURRICULUM_PATH: CurriculumModule[] = [
  ...CORE_MODULES,
  ...WORD_MODULES,
  ...SENT_MODULES
];
