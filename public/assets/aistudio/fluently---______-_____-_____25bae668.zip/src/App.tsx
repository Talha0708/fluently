import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Flame, Heart, Trophy, Star, Play, Volume2, CheckCircle2, XCircle, 
  ArrowRight, RotateCcw, Award, BookOpen, User, Home, Sparkles, Check, 
  Zap, Search, VolumeX, Settings, ShieldCheck, RefreshCw, BarChart2,
  Bookmark, ChevronRight, HelpCircle, FastForward, Turtle, Layers, Compass,
  Info, ChevronLeft, ExternalLink, Target, Gift, Shield, CheckCheck
} from 'lucide-react';

import { ALL_WORDS_DATABASE, ALL_CATEGORIES, WordItem } from './data/wordsData';
import { SENTENCE_BANK, SENTENCE_CATEGORIES, SentenceItem } from './data/sentencesData';
import { 
  ALL_CURRICULUM_PATH, CORE_MODULES, WORD_MODULES, SENT_MODULES, 
  STAGES, DAILY_QUESTS, STREAK_MILESTONES, ACHIEVEMENTS, 
  CurriculumModule, Lesson, Question 
} from './data/curriculumData';

// ==========================================
// 1. AUDIO & SOUND EFFECTS SYNTHESIZER
// ==========================================
const playSound = (type: 'correct' | 'wrong' | 'complete' | 'levelup' | 'reward' | 'gem') => {
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);

    if (type === 'correct') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
      osc.frequency.exponentialRampToValueAtTime(659.25, ctx.currentTime + 0.1); // E5
      osc.frequency.exponentialRampToValueAtTime(783.99, ctx.currentTime + 0.2); // G5
      gain.gain.setValueAtTime(0.25, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.35);
      osc.start();
      osc.stop(ctx.currentTime + 0.35);
    } else if (type === 'wrong') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(220, ctx.currentTime); // A3
      osc.frequency.setValueAtTime(164.81, ctx.currentTime + 0.15); // E3
      gain.gain.setValueAtTime(0.25, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.35);
      osc.start();
      osc.stop(ctx.currentTime + 0.35);
    } else if (type === 'complete' || type === 'levelup' || type === 'reward') {
      const notes = type === 'levelup' ? [523.25, 659.25, 783.99, 1046.50, 1318.51] : [523.25, 659.25, 783.99, 1046.50];
      notes.forEach((freq, idx) => {
        const noteOsc = ctx.createOscillator();
        const noteGain = ctx.createGain();
        noteOsc.type = 'triangle';
        noteOsc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.08);
        noteGain.gain.setValueAtTime(0.2, ctx.currentTime + idx * 0.08);
        noteGain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + idx * 0.08 + 0.3);
        noteOsc.connect(noteGain);
        noteGain.connect(ctx.destination);
        noteOsc.start(ctx.currentTime + idx * 0.08);
        noteOsc.stop(ctx.currentTime + idx * 0.08 + 0.3);
      });
    } else if (type === 'gem') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(987.77, ctx.currentTime); // B5
      osc.frequency.exponentialRampToValueAtTime(1318.51, ctx.currentTime + 0.12); // E6
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.25);
      osc.start();
      osc.stop(ctx.currentTime + 0.25);
    }
  } catch (e) {
    console.log('Web Audio disabled or blocked');
  }
};

const speakText = (text: string, isSlow = false) => {
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-US';
    utterance.rate = isSlow ? 0.6 : 0.88;
    window.speechSynthesis.speak(utterance);
  }
};

// ==========================================
// 2. DUOLINGO DESIGN CSS CONSTANTS
// ==========================================
const DUO_CSS = String.raw`
@import url('https://fonts.googleapis.com/css2?family=Nunito:wght@600;700;800;900&family=Hind+Siliguri:wght@500;600;700&display=swap');
.rk{font-family:'Nunito','Hind Siliguri',system-ui,sans-serif;color:#4B4B4B;background:#fff}
.rk.bg-slate-100{background:#fff}
.rk .text-slate-800{color:#3C3C3C}
.rk .bg-sky-500{background:#1CB0F6}
.rk .hover\:bg-sky-600:hover{background:#49C0F8}
.rk .border-sky-700{border-color:#1899D6}
.rk .bg-sky-50,.rk .bg-sky-100{background:#DDF4FF}
.rk .text-sky-600,.rk .text-sky-700,.rk .text-sky-800{color:#1899D6}
.rk .border-sky-200,.rk .border-sky-300{border-color:#84D8FF}
.rk .border-slate-200,.rk .border-slate-300{border-color:#E5E5E5}
.rk .shadow-md,.rk .shadow-lg,.rk .shadow-xl,.rk .shadow-sm{box-shadow:none}
.rk .rounded-3xl{border-width:2px;border-bottom-width:4px}
.rk .rounded-3xl.shadow-xl{box-shadow:none}
.rk header{background:#fff;border-bottom:2px solid #E5E5E5;box-shadow:none}
.rk .bg-gradient-to-tr{background:#1CB0F6;background-image:none;border-bottom:4px solid #1899D6}
.rk .bg-gradient-to-r.from-sky-500{background:#1CB0F6;background-image:none;border:0;border-bottom:6px solid #1899D6}
.rk footer{background:#fff;border-top:2px solid #E5E5E5;box-shadow:none}
.rk footer .bg-sky-50{background:#DDF4FF;border:2px solid #84D8FF}
.rk footer .text-sky-600{color:#1CB0F6}
.rk .border-b-4:active{border-bottom-width:0;transform:translateY(4px)}
.rk .duo-node{transition:transform .08s,box-shadow .08s}
.rk .duo-node:active{transform:translateY(5px);box-shadow:0 1px 0 rgba(0,0,0,.25)!important}
.rk :focus-visible{outline:3px solid #1CB0F6;outline-offset:2px}
@media (prefers-reduced-motion:reduce){.rk *{animation:none!important}}
`;

const UNIT_COLORS = [
  ['#1CB0F6', '#1899D6'], 
  ['#6366F1', '#4F46E5'], 
  ['#CE82FF', '#A568CC'], 
  ['#FF9600', '#CC7800'], 
  ['#FF4B4B', '#D33131'], 
  ['#2B70C9', '#1E5298']
];

// Helpers
const bnNum = (n: number) => String(n).replace(/\d/g, d => '০১২৩৪৫৬৭৮৯'[Number(d)]);
const dayKey = (d = new Date()) => new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);

const calcStreak = (days: string[] = []) => {
  const set = new Set(days);
  let n = 0;
  const d = new Date();
  if (!set.has(dayKey(d))) d.setDate(d.getDate() - 1);
  while (set.has(dayKey(d))) {
    n++;
    d.setDate(d.getDate() - 1);
  }
  return n;
};

const daysAgo = (key: string | null) => (key ? Math.round((new Date(dayKey()).getTime() - new Date(key).getTime()) / 86400000) : null);
const agoText = (n: number | null) => (n === null ? '' : n === 0 ? 'আজ' : `${n} দিন আগে`);
const scoreColor = (p: number) => (p >= 80 ? 'text-sky-700 bg-sky-50 border-sky-300' : p >= 60 ? 'text-amber-700 bg-amber-50 border-amber-300' : 'text-rose-700 bg-rose-50 border-rose-300');

const DAILY_GOAL = 50;
const LEVEL_TITLES = ['শিক্ষানবিশ 🌱', 'উৎসাহী 🔥', 'পাঠক 📖', 'বক্তা 🗣️', 'দক্ষ ⚡', 'বিশেষজ্ঞ 🎯', 'মাস্টার 👑', 'লিজেন্ড 🏆'];
const levelTitle = (lv: number) => LEVEL_TITLES[Math.min(lv - 1, LEVEL_TITLES.length - 1)];
const COMBO_MSGS = ['', '', '🔥 কম্বো x2!', '⚡ আনস্টপেবল x3! +৫ বোনাস', '🚀 অগ্নিঝড় x4! +৫ বোনাস', '👑 কিংবদন্তি x5! +৫ বোনাস'];
const buzz = (ms: number | number[]) => { try { navigator.vibrate && navigator.vibrate(ms); } catch (e) {} };

const Confetti = () => {
  const bits = useMemo(() => Array.from({ length: 48 }, (_, i) => ({
    left: Math.random() * 100,
    delay: Math.random() * 0.8,
    dur: 2 + Math.random() * 1.8,
    color: ['#0ea5e9', '#facc15', '#f43f5e', '#6366f1', '#06b6d4', '#f97316'][i % 6],
    rot: Math.random() * 360
  })), []);

  return (
    <div className="pointer-events-none fixed inset-0 overflow-hidden z-50">
      {bits.map((b, i) => (
        <span 
          key={i} 
          className="fl-confetti" 
          style={{ 
            left: `${b.left}%`, 
            background: b.color, 
            animationDelay: `${b.delay}s`, 
            animationDuration: `${b.dur}s`, 
            transform: `rotate(${b.rot}deg)` 
          }} 
        />
      ))}
    </div>
  );
};

// Pagination Helpers
const PAGE_SIZE = 20;
const loadPage = (k: string) => { 
  try { 
    return Math.max(1, parseInt(JSON.parse(localStorage.getItem('fluently_pages_v2') || '{}')[k], 10) || 1); 
  } catch (e) { 
    return 1; 
  } 
};
const savePage = (k: string, v: number) => { 
  try { 
    const o = JSON.parse(localStorage.getItem('fluently_pages_v2') || '{}'); 
    o[k] = v; 
    localStorage.setItem('fluently_pages_v2', JSON.stringify(o)); 
  } catch (e) {} 
};

interface PagerProps {
  page: number;
  total: number;
  onChange: (p: number) => void;
}

const Pager: React.FC<PagerProps> = ({ page, total, onChange }) => {
  if (total <= 1) return null;
  const nums: number[] = [];
  const add = (n: number) => { if (n >= 1 && n <= total && !nums.includes(n)) nums.push(n); };
  add(1); 
  for (let n = page - 2; n <= page + 2; n++) add(n); 
  add(total);
  nums.sort((a, b) => a - b);
  
  const items: (number | string)[] = [];
  nums.forEach((n, i) => { 
    if (i > 0 && n - nums[i - 1] > 1) items.push('gap' + n); 
    items.push(n); 
  });
  
  const btn = 'min-w-[40px] h-10 px-3 rounded-xl border-2 font-black text-sm transition-all';
  return (
    <div className="bg-white rounded-3xl border-2 border-slate-200 p-4 space-y-3">
      <p className="text-center text-xs font-extrabold text-slate-500">পেজ {page} / {total}</p>
      <div className="flex flex-wrap items-center justify-center gap-2">
        <button 
          disabled={page <= 1} 
          onClick={() => onChange(page - 1)} 
          className={`${btn} flex items-center gap-1 border-slate-200 text-slate-600 disabled:opacity-40`}
        >
          <ChevronLeft className="w-4 h-4" /> আগের
        </button>
        {items.map(n => typeof n === 'string'
          ? <span key={n} className="text-slate-400 font-black">…</span>
          : (
            <button 
              key={n} 
              onClick={() => onChange(n)} 
              className={`${btn} ${n === page ? 'bg-sky-500 border-sky-700 text-white' : 'bg-white border-slate-200 text-slate-600 hover:border-sky-400'}`}
            >
              {n}
            </button>
          ))}
        <button 
          disabled={page >= total} 
          onClick={() => onChange(page + 1)} 
          className={`${btn} flex items-center gap-1 border-slate-200 text-slate-600 disabled:opacity-40`}
        >
          পরের <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

const FacebookIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...props}>
    <path d="M13.5 21v-7.5h2.5l.5-3h-3V8.6c0-.9.3-1.5 1.6-1.5H16.7V4.4c-.3 0-1.2-.1-2.3-.1-2.3 0-3.9 1.4-3.9 4v2.2H8v3h2.5V21h3z" />
  </svg>
);

// ==========================================
// 3. MAIN APP COMPONENT
// ==========================================
export default function App() {
  // --- Persistent User Stats ---
  interface UserStatsState {
    xp: number;
    gems: number;
    hearts: number;
    maxHearts: number;
    completedLessons: string[];
    level: number;
    savedWords: WordItem[];
    savedSentences: number[];
    daily: Record<string, { xp: number; lessons: number; correct: number; total: number; sec: number }>;
    history: Record<string, { attempts: number; best: number; last: number; lastDate: string }>;
    exams: { date: string; pct: number; total: number }[];
    activeDays: string[];
    streakFreezes: number;
    claimedStreakMilestones: number[];
    claimedQuests: Record<string, string>; // questId -> lastClaimedDay
  }

  const DEFAULT_STATS: UserStatsState = { 
    xp: 0, 
    gems: 25, 
    hearts: 5, 
    maxHearts: 5, 
    completedLessons: [], 
    level: 1, 
    savedWords: [], 
    savedSentences: [], 
    daily: {}, 
    history: {}, 
    exams: [], 
    activeDays: [],
    streakFreezes: 1,
    claimedStreakMilestones: [],
    claimedQuests: {}
  };

  const [userStats, setUserStats] = useState<UserStatsState>(() => {
    try {
      const saved = localStorage.getItem('fluently_stats_v3');
      if (saved) return { ...DEFAULT_STATS, ...JSON.parse(saved) };
    } catch (e) {}
    return DEFAULT_STATS;
  });

  // Settings
  const [isSlowAudio, setIsSlowAudio] = useState<boolean>(() => { 
    try { 
      return JSON.parse(localStorage.getItem('fluently_settings_v2') || '{}').slow || false; 
    } catch (e) { 
      return false; 
    } 
  });
  const [fontSize, setFontSize] = useState<string>(() => { 
    try { 
      return JSON.parse(localStorage.getItem('fluently_settings_v2') || '{}').font || 'normal'; 
    } catch (e) { 
      return 'normal'; 
    } 
  });

  useEffect(() => { 
    try { 
      localStorage.setItem('fluently_settings_v2', JSON.stringify({ slow: isSlowAudio, font: fontSize })); 
    } catch (e) {} 
  }, [isSlowAudio, fontSize]);

  // Save Stats to LocalStorage
  useEffect(() => {
    localStorage.setItem('fluently_stats_v3', JSON.stringify(userStats));
  }, [userStats]);

  // Navigation
  const [activeTab, setActiveTab] = useState<'path' | 'dictionary' | 'sentences' | 'leaderboard' | 'profile' | 'about' | 'lesson'>('path');

  // Stage & Path Filters (Duolingo-like progression)
  const [selectedStage, setSelectedStage] = useState<string>('all'); // 'all', 'A1', 'A2', 'B1', 'B2', 'C1', 'word', 'sent'

  // Active Lesson State
  const [activeLesson, setActiveLesson] = useState<Lesson | null>(null);
  const [questionIdx, setQuestionIdx] = useState(0);
  const [selectedOpt, setSelectedOpt] = useState<string | null>(null);
  const [reorderedWords, setReorderedWords] = useState<string[]>([]);
  const [availableWords, setAvailableWords] = useState<string[]>([]);
  const [matchedPairs, setMatchedPairs] = useState<Record<string, string>>({});
  const [selectedEn, setSelectedEn] = useState<string | null>(null);
  const [isAnswerChecked, setIsAnswerChecked] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [showSummary, setShowSummary] = useState(false);
  const [lessonXpEarned, setLessonXpEarned] = useState(0);
  const [lessonCorrect, setLessonCorrect] = useState(0);
  const lessonStartRef = useRef(Date.now());
  const [combo, setCombo] = useState(0);
  const [bestCombo, setBestCombo] = useState(0);
  const [comboToast, setComboToast] = useState('');
  const levelAtStartRef = useRef(1);

  // Modals & Banners
  const [showStreakModal, setShowStreakModal] = useState(false);
  const [showQuestsModal, setShowQuestsModal] = useState(false);

  // Dictionary Search & Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedLevel, setSelectedLevel] = useState('All');
  const [wordPage, setWordPage] = useState(() => loadPage('words'));

  // Sentence Bank Filters
  const [sentCat, setSentCat] = useState('All');
  const [sentLevel, setSentLevel] = useState('All');
  const [sentSearch, setSentSearch] = useState('');
  const [showBn, setShowBn] = useState(true);
  const [onlySaved, setOnlySaved] = useState(false);
  const [sentPage, setSentPage] = useState(() => loadPage('sents'));

  // Handle Question Initialization
  useEffect(() => {
    if (activeLesson) {
      const q = activeLesson.questions[questionIdx];
      setIsAnswerChecked(false);
      setSelectedOpt(null);
      setSelectedEn(null);
      setMatchedPairs({});
      
      if (q && q.type === 'reorder') {
        const shuffled = [...(q.words || [])].sort(() => Math.random() - 0.5);
        setAvailableWords(shuffled);
        setReorderedWords([]);
      }
    }
  }, [activeLesson, questionIdx]);

  // Lesson Trigger
  const startLesson = (lesson: Lesson) => {
    const modId = lesson.moduleId || ALL_CURRICULUM_PATH.find(m => m.lessons.some(l => l.id === lesson.id))?.id;
    setActiveLesson({ ...lesson, moduleId: modId });
    setLessonCorrect(0);
    lessonStartRef.current = Date.now();
    levelAtStartRef.current = userStats.level;
    setCombo(0); 
    setBestCombo(0); 
    setComboToast('');
    setQuestionIdx(0);
    setShowSummary(false);
    setLessonXpEarned(0);
    setActiveTab('lesson');
  };

  const startModule = (m: CurriculumModule) => startLesson({
    id: m.id + '_all', 
    moduleId: m.id, 
    title: m.title,
    xp: m.lessons.reduce((n, l) => n + l.xp, 0),
    questions: m.lessons.flatMap(l => l.questions)
  });

  const startExam = () => {
    const pool = ALL_CURRICULUM_PATH.flatMap(m => m.lessons.flatMap(l => l.questions));
    const picked = [...pool].sort(() => Math.random() - 0.5).slice(0, 10);
    startLesson({ id: 'exam', title: 'পরীক্ষা (Exam)', xp: 40, isExam: true, questions: picked });
  };

  const handleRefillHearts = () => {
    if (userStats.hearts >= userStats.maxHearts) return;
    setUserStats(prev => ({ ...prev, hearts: prev.maxHearts }));
    playSound('correct');
  };

  // Buy Streak Freeze with Gems
  const handleBuyStreakFreeze = () => {
    if (userStats.gems < 20) {
      alert('আপনার পর্যাপ্ত জেম (💎 ২০টি) নেই। লেসন শেষ করে জেম অর্জন করুন!');
      return;
    }
    setUserStats(prev => ({
      ...prev,
      gems: prev.gems - 20,
      streakFreezes: prev.streakFreezes + 1
    }));
    playSound('gem');
  };

  // Claim Streak Milestone
  const handleClaimStreakMilestone = (m: typeof STREAK_MILESTONES[0]) => {
    if (userStats.claimedStreakMilestones.includes(m.days)) return;
    const currentStreak = calcStreak(userStats.activeDays);
    if (currentStreak < m.days) return;

    setUserStats(prev => ({
      ...prev,
      xp: prev.xp + m.xp,
      gems: prev.gems + m.gems,
      claimedStreakMilestones: [...prev.claimedStreakMilestones, m.days]
    }));
    playSound('reward');
  };

  // Claim Daily Quest
  const handleClaimQuest = (q: typeof DAILY_QUESTS[0]) => {
    const today = dayKey();
    if (userStats.claimedQuests[q.id] === today) return;

    setUserStats(prev => ({
      ...prev,
      xp: prev.xp + q.xp,
      gems: prev.gems + q.gems,
      claimedQuests: { ...prev.claimedQuests, [q.id]: today }
    }));
    playSound('gem');
  };

  // Lesson Checking
  const handleCheckAnswer = () => {
    if (isAnswerChecked || !activeLesson) return;

    const currentQ = activeLesson.questions[questionIdx];
    let correct = false;

    if (currentQ.type === 'mcq' || currentQ.type === 'listening') {
      correct = selectedOpt === currentQ.answer;
    } else if (currentQ.type === 'reorder') {
      correct = JSON.stringify(reorderedWords) === JSON.stringify(currentQ.answer);
    } else if (currentQ.type === 'matching') {
      correct = Object.keys(matchedPairs).length === (currentQ.pairs?.length || 0);
    }

    setIsCorrect(correct);
    setIsAnswerChecked(true);

    if (correct) {
      playSound('correct');
      buzz(30);
      const nc = combo + 1;
      const bonus = nc >= 3 ? 5 : 0;
      setCombo(nc);
      setBestCombo(b => Math.max(b, nc));
      setComboToast(COMBO_MSGS[Math.min(nc, 5)] || '');
      setLessonXpEarned(prev => prev + 10 + bonus);
      setLessonCorrect(prev => prev + 1);
    } else {
      playSound('wrong');
      buzz([60, 40, 60]);
      setCombo(0); 
      setComboToast('');
      setUserStats(prev => ({
        ...prev,
        hearts: Math.max(0, prev.hearts - 1)
      }));
    }
  };

  const handleNextQuestion = () => {
    if (!activeLesson) return;
    if (questionIdx + 1 < activeLesson.questions.length) {
      setQuestionIdx(prev => prev + 1);
    } else {
      // Lesson Complete
      playSound('complete');
      setShowSummary(true);
      const totalXpGained = activeLesson.xp + lessonXpEarned;
      const pct = Math.round((lessonCorrect / activeLesson.questions.length) * 100);
      const today = dayKey();
      const secs = Math.min(3600, Math.round((Date.now() - lessonStartRef.current) / 1000));
      
      setUserStats(prev => {
        const h = { ...(prev.history || {}) };
        const bump = (key: string) => {
          const o = h[key] || { attempts: 0, best: 0, last: 0, lastDate: today };
          h[key] = { attempts: o.attempts + 1, best: Math.max(o.best, pct), last: pct, lastDate: today };
        };
        if (!activeLesson.isExam) {
          if (!activeLesson.id.endsWith('_all')) bump(activeLesson.id);
          if (activeLesson.moduleId) bump(activeLesson.moduleId);
        }
        const dy = { ...(prev.daily || {}) };
        const d0 = dy[today] || { xp: 0, lessons: 0, correct: 0, total: 0, sec: 0 };
        dy[today] = { 
          xp: d0.xp + totalXpGained, 
          lessons: d0.lessons + 1, 
          correct: d0.correct + lessonCorrect, 
          total: d0.total + activeLesson.questions.length, 
          sec: d0.sec + secs 
        };
        
        const xp = prev.xp + totalXpGained;
        const newGems = prev.gems + (pct === 100 ? 5 : 2);
        
        return {
          ...prev, 
          daily: dy, 
          xp, 
          gems: newGems,
          level: Math.floor(xp / 100) + 1, 
          history: h,
          exams: activeLesson.isExam ? [...(prev.exams || []), { date: today, pct, total: activeLesson.questions.length }] : (prev.exams || []),
          completedLessons: activeLesson.isExam || activeLesson.id.endsWith('_all') ? prev.completedLessons : Array.from(new Set([...prev.completedLessons, activeLesson.id])),
          activeDays: Array.from(new Set([...(prev.activeDays || []), today]))
        };
      });
    }
  };

  // Bookmark / Save Word into User Bank
  const toggleSaveWord = (wordObj: WordItem) => {
    setUserStats(prev => {
      const exists = prev.savedWords.some(w => w.id === wordObj.id);
      const updated = exists 
        ? prev.savedWords.filter(w => w.id !== wordObj.id)
        : [...prev.savedWords, wordObj];
      return { ...prev, savedWords: updated };
    });
  };

  const toggleSaveSentence = (id: number) => {
    setUserStats(prev => {
      const cur = prev.savedSentences || [];
      return { ...prev, savedSentences: cur.includes(id) ? cur.filter(x => x !== id) : [...cur, id] };
    });
  };

  // Filtered Sentences
  const filteredSentences = useMemo(() => SENTENCE_BANK.filter(x =>
    (sentCat === 'All' || x.category === sentCat) &&
    (sentLevel === 'All' || x.level === sentLevel) &&
    (!onlySaved || (userStats.savedSentences || []).includes(x.id)) &&
    (x.en.toLowerCase().includes(sentSearch.toLowerCase()) || x.bn.includes(sentSearch))
  ), [sentCat, sentLevel, sentSearch, onlySaved, userStats.savedSentences]);

  const sentenceOfTheDay = SENTENCE_BANK[(new Date().getDate() * 7) % SENTENCE_BANK.length];

  // Filtered Words
  const filteredWords = useMemo(() => {
    return ALL_WORDS_DATABASE.filter(w => {
      const matchesSearch = w.word.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            w.bn.includes(searchTerm) || 
                            (w.phonetic || '').includes(searchTerm);
      const matchesCat = selectedCategory === 'All' || w.category === selectedCategory;
      const matchesLvl = selectedLevel === 'All' || w.level === selectedLevel;
      return matchesSearch && matchesCat && matchesLvl;
    });
  }, [searchTerm, selectedCategory, selectedLevel]);

  const totalWordPages = Math.max(1, Math.ceil(filteredWords.length / PAGE_SIZE));
  const curWordPage = Math.min(wordPage, totalWordPages);
  const pagedWords = filteredWords.slice((curWordPage - 1) * PAGE_SIZE, curWordPage * PAGE_SIZE);
  
  const totalSentPages = Math.max(1, Math.ceil(filteredSentences.length / PAGE_SIZE));
  const curSentPage = Math.min(sentPage, totalSentPages);
  const pagedSents = filteredSentences.slice((curSentPage - 1) * PAGE_SIZE, curSentPage * PAGE_SIZE);
  
  const goWordPage = (p: number) => { 
    setWordPage(p); 
    savePage('words', p); 
    window.scrollTo({ top: 0, behavior: 'smooth' }); 
  };
  
  const goSentPage = (p: number) => { 
    setSentPage(p); 
    savePage('sents', p); 
    window.scrollTo({ top: 0, behavior: 'smooth' }); 
  };

  const hist = userStats.history || {};
  const pctNow = activeLesson ? Math.round((lessonCorrect / activeLesson.questions.length) * 100) : 0;
  
  const weakModules = ALL_CURRICULUM_PATH.filter(m => hist[m.id] && (hist[m.id].last < 70 || (daysAgo(hist[m.id].lastDate) ?? 0) >= 3))
    .sort((a, b) => hist[a.id].last - hist[b.id].last).slice(0, 3);

  // Duolingo Path Filter
  const displayedModules = useMemo(() => {
    if (selectedStage === 'all') {
      return CORE_MODULES;
    } else if (selectedStage === 'word') {
      return WORD_MODULES;
    } else if (selectedStage === 'sent') {
      return SENT_MODULES;
    } else {
      return CORE_MODULES.filter(m => m.stageId === selectedStage);
    }
  }, [selectedStage]);

  // Stage Progress Calculation
  const stageProgress = useMemo(() => {
    return STAGES.map(stage => {
      const stageMods = CORE_MODULES.filter(m => m.stageId === stage.id);
      const stageLessons = stageMods.flatMap(m => m.lessons);
      const completed = stageLessons.filter(l => userStats.completedLessons.includes(l.id)).length;
      const total = stageLessons.length;
      const pct = total ? Math.round((completed / total) * 100) : 0;
      return { ...stage, completed, total, pct };
    });
  }, [userStats.completedLessons]);

  const currentStreak = calcStreak(userStats.activeDays);
  const todayXp = (userStats.daily || {})[dayKey()]?.xp || 0;
  const todayLessons = (userStats.daily || {})[dayKey()]?.lessons || 0;

  return (
    <div className={`rk min-h-screen bg-slate-100 text-slate-800 font-sans flex flex-col justify-between selection:bg-sky-200 ${fontSize === 'large' ? 'text-lg' : 'text-base'}`}>
      <style>{DUO_CSS}</style>
      <style>{`
        @keyframes flFall { 0% { top: -5%; opacity: 1; } 100% { top: 105%; opacity: 0.9; } }
        .fl-confetti { position: absolute; top: -5%; width: 10px; height: 14px; border-radius: 2px; animation: flFall linear forwards; }
        @keyframes flPop { 0% { transform: scale(.6); opacity: 0; } 60% { transform: scale(1.15); } 100% { transform: scale(1); opacity: 1; } }
        .fl-pop { animation: flPop .35s ease-out; }
      `}</style>
      
      {/* ================= TOP BRAND HEADER ================= */}
      <header className="sticky top-0 z-40 bg-white border-b-2 border-slate-200 shadow-sm px-4 py-3">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          
          {/* Logo */}
          <div 
            onClick={() => setActiveTab('path')}
            className="flex items-center space-x-2.5 cursor-pointer group"
          >
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-sky-500 to-sky-400 flex items-center justify-center text-white font-black text-2xl shadow-md group-hover:scale-105 transition-transform">
              F
            </div>
            <div>
              <span className="font-extrabold text-2xl tracking-tight text-slate-800 group-hover:text-sky-600 transition-colors">
                Fluently
              </span>
              <span className="block text-[10px] font-extrabold uppercase tracking-widest text-sky-600">
                ইংরেজি শিখুন সহজে · {ALL_WORDS_DATABASE.length} শব্দ ও {SENTENCE_BANK.length} বাক্য
              </span>
            </div>
          </div>

          {/* User Gamification Counters */}
          <div className="flex items-center space-x-2 sm:space-x-3 font-black text-xs sm:text-sm">
            {/* Streak with click to open streak reward modal */}
            <button
              onClick={() => setShowStreakModal(true)}
              title="স্ট্রিক ও রিওয়ার্ড দেখুন"
              className="flex items-center space-x-1.5 text-amber-500 bg-amber-50 px-3 py-1.5 rounded-full border border-amber-200 shadow-sm hover:bg-amber-100 transition-all cursor-pointer"
            >
              <Flame className="w-4 h-4 sm:w-5 sm:h-5 fill-amber-500 animate-pulse" />
              <span>{currentStreak} দিন</span>
            </button>

            {/* Gems */}
            <div 
              title="আপনার অর্জিত জেম"
              className="flex items-center space-x-1.5 text-cyan-600 bg-cyan-50 px-2.5 sm:px-3 py-1.5 rounded-full border border-cyan-200 shadow-sm"
            >
              <span className="text-sm">💎</span>
              <span>{userStats.gems}</span>
            </div>

            {/* XP */}
            <div className="flex items-center space-x-1.5 text-yellow-600 bg-yellow-50 px-2.5 sm:px-3 py-1.5 rounded-full border border-yellow-200 shadow-sm">
              <Zap className="w-4 h-4 sm:w-5 sm:h-5 fill-yellow-500" />
              <span>{userStats.xp} XP</span>
            </div>

            {/* Hearts */}
            <button
              onClick={handleRefillHearts}
              title="ক্লিক করে হার্ট রিফিল করুন!"
              className="flex items-center space-x-1.5 text-rose-500 bg-rose-50 px-2.5 sm:px-3 py-1.5 rounded-full border border-rose-200 hover:bg-rose-100 transition-colors shadow-sm"
            >
              <Heart className="w-4 h-4 sm:w-5 sm:h-5 fill-rose-500" />
              <span>{userStats.hearts}</span>
            </button>
          </div>

        </div>
      </header>

      {/* ================= STREAK REWARDS MODAL ================= */}
      {showStreakModal && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border-2 border-slate-200 max-w-md w-full p-6 space-y-5 shadow-2xl relative animate-fadeIn">
            <button 
              onClick={() => setShowStreakModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-1"
            >
              <XCircle className="w-6 h-6" />
            </button>

            <div className="text-center space-y-2">
              <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto text-3xl text-amber-600 border-2 border-amber-300">
                🔥
              </div>
              <h3 className="text-2xl font-black text-slate-800">স্ট্রিক ও রিওয়ার্ড (Streak Rewards)</h3>
              <p className="text-xs sm:text-sm font-semibold text-slate-500">
                প্রতিদিন অন্তত একটি লেসন সম্পন্ন করে স্ট্রিক বাড়ান এবং আকর্ষণীয় পুরষ্কার জিতে নিন!
              </p>
            </div>

            {/* Current Streak & Freeze Status */}
            <div className="bg-amber-50 border-2 border-amber-200 rounded-2xl p-4 flex items-center justify-between">
              <div>
                <p className="text-xs font-black text-amber-800 uppercase tracking-wider">বর্তমান স্ট্রিক</p>
                <p className="text-2xl font-black text-amber-600">{currentStreak} দিন টানা</p>
              </div>
              <div className="text-right">
                <span className="inline-flex items-center gap-1 text-xs font-black px-2.5 py-1 rounded-full bg-cyan-100 text-cyan-800 border border-cyan-300">
                  <Shield className="w-3.5 h-3.5" /> শিল্ড: {userStats.streakFreezes}টি
                </span>
                <p className="text-[10px] font-bold text-slate-500 mt-1">একদিন মিস করলেও স্ট্রিক বাঁচবে</p>
              </div>
            </div>

            {/* Streak Milestones */}
            <div className="space-y-3">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-400">স্ট্রিক মাইলস্টোন পুরষ্কার</h4>
              {STREAK_MILESTONES.map(m => {
                const isClaimed = userStats.claimedStreakMilestones.includes(m.days);
                const canClaim = currentStreak >= m.days && !isClaimed;
                return (
                  <div 
                    key={m.days} 
                    className={`flex items-center justify-between p-3 rounded-2xl border-2 transition-all ${
                      isClaimed 
                        ? 'bg-slate-50 border-slate-200 opacity-70' 
                        : canClaim 
                        ? 'bg-amber-50 border-amber-400 shadow-sm' 
                        : 'bg-white border-slate-200'
                    }`}
                  >
                    <div>
                      <p className="font-extrabold text-sm text-slate-800">{m.badge} · {m.title}</p>
                      <p className="text-xs font-semibold text-slate-500">
                        +{m.xp} XP · +{m.gems} 💎 · {m.rewardName}
                      </p>
                    </div>

                    {isClaimed ? (
                      <span className="text-xs font-black text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-xl border border-emerald-200 flex items-center gap-1">
                        <Check className="w-3 h-3 stroke-[3]" /> নেওয়া হয়েছে
                      </span>
                    ) : canClaim ? (
                      <button
                        onClick={() => handleClaimStreakMilestone(m)}
                        className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-white font-black text-xs rounded-xl shadow-sm border-b-2 border-amber-700 cursor-pointer"
                      >
                        দাবি করুন 🎁
                      </button>
                    ) : (
                      <span className="text-xs font-bold text-slate-400">
                        আর {m.days - currentStreak} দিন
                      </span>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Buy Streak Freeze */}
            <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
              <div>
                <p className="font-black text-xs text-slate-800">স্ট্রিক শিল্ড কিনুন (Streak Freeze)</p>
                <p className="text-[11px] font-bold text-slate-400">২০ জেম দিয়ে স্ট্রিক সুরক্ষা নিশ্চিত করুন</p>
              </div>
              <button
                onClick={handleBuyStreakFreeze}
                disabled={userStats.gems < 20}
                className="px-3.5 py-2 bg-cyan-500 hover:bg-cyan-600 text-white font-black text-xs rounded-xl border-b-2 border-cyan-700 disabled:opacity-50 flex items-center gap-1 cursor-pointer"
              >
                💎 ২০ জেম দিয়ে কিনুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= MAIN CONTENT AREA ================= */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 py-6">

        {/* ---------------- TABS 1: LEARNING PATH ---------------- */}
        {activeTab === 'path' && (
          <div className="space-y-8 animate-fadeIn">
            
            {/* Welcome Banner */}
            <div className="bg-gradient-to-r from-sky-500 via-sky-600 to-blue-600 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden flex flex-col sm:flex-row items-center justify-between">
              <div className="space-y-3 z-10 max-w-xl text-center sm:text-left">
                <span className="bg-white/20 backdrop-blur-md text-xs font-bold px-3.5 py-1.5 rounded-full uppercase tracking-wider text-sky-100">
                  ৩০০০+ শব্দ ও ১০০০+ বাক্য · ডুওলিঙ্গো স্টাইল
                </span>
                <h1 className="text-2xl sm:text-4xl font-black leading-tight">
                  Beginner থেকে Advanced ইংরেজি শিখুন সহজে!
                </h1>
                <p className="text-sky-100 text-sm sm:text-base font-medium">
                  প্রতিদিন মাত্র ১০ মিনিটের খেলায় আয়ত্ত করুন বাস্তব জীবনের প্রয়োজনীয় ইংরেজি শব্দ, ব্যাকরণ ও বাক্য।
                </p>
                <div className="flex flex-wrap items-center gap-2 pt-1 justify-center sm:justify-start">
                  <button 
                    onClick={() => setShowQuestsModal(true)}
                    className="px-3.5 py-1.5 rounded-xl bg-white text-sky-700 font-extrabold text-xs shadow-md border-b-2 border-sky-200 flex items-center gap-1 hover:bg-sky-50 transition-all cursor-pointer"
                  >
                    <Target className="w-3.5 h-3.5" /> আজকের মিশন (Quests)
                  </button>
                  <button 
                    onClick={() => setShowStreakModal(true)}
                    className="px-3.5 py-1.5 rounded-xl bg-amber-400 text-amber-950 font-extrabold text-xs shadow-md border-b-2 border-amber-600 flex items-center gap-1 hover:bg-amber-300 transition-all cursor-pointer"
                  >
                    <Flame className="w-3.5 h-3.5 fill-current" /> স্ট্রিক রিওয়ার্ড
                  </button>
                </div>
              </div>

              <div className="mt-6 sm:mt-0 z-10 flex flex-col items-center">
                <div className="w-20 h-20 sm:w-24 sm:h-24 bg-white/10 rounded-3xl flex items-center justify-center border-4 border-white/30 backdrop-blur-md text-5xl shadow-2xl mb-2">
                  🦉
                </div>
                <div className="bg-white text-sky-700 font-extrabold text-xs px-3 py-1.5 rounded-full shadow-md">
                  লেভেল {userStats.level} · {levelTitle(userStats.level)}
                </div>
                <div className="w-32 mt-2">
                  <div className="h-2.5 bg-white/25 rounded-full overflow-hidden">
                    <div className="h-full bg-yellow-300 rounded-full transition-all duration-700" style={{ width: `${userStats.xp % 100}%` }} />
                  </div>
                  <p className="text-[10px] font-bold text-sky-100 mt-1 text-center">পরের লেভেলে আর {100 - (userStats.xp % 100)} XP</p>
                </div>
              </div>
            </div>

            {/* CEFR Progression Progress Tracker */}
            <div className="bg-white rounded-3xl border-2 border-slate-200 p-5 shadow-sm space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                <div>
                  <h3 className="text-base sm:text-lg font-black text-slate-800 flex items-center gap-2">
                    <Compass className="w-5 h-5 text-sky-600" />
                    লেভেল অগ্রগতি (CEFR Beginner to Advanced Progress)
                  </h3>
                  <p className="text-xs font-semibold text-slate-500">
                    ধাপে ধাপে এগিয়ে যান প্রারম্ভিক থেকে আন্তর্জাতিক মানের সাবলীলতায়।
                  </p>
                </div>
                <div className="flex items-center gap-3 text-xs font-extrabold text-slate-600">
                  <span className="bg-sky-50 text-sky-700 px-3 py-1 rounded-xl border border-sky-200">
                    📚 শব্দ: {userStats.savedWords.length} / {ALL_WORDS_DATABASE.length}
                  </span>
                  <span className="bg-emerald-50 text-emerald-700 px-3 py-1 rounded-xl border border-emerald-200">
                    💬 বাক্য: {userStats.savedSentences.length} / {SENTENCE_BANK.length}
                  </span>
                </div>
              </div>

              {/* Progress bars for A1, A2, B1, B2, C1 */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-1">
                {stageProgress.map(st => (
                  <div key={st.id} className="bg-slate-50 border-2 border-slate-200 rounded-2xl p-3 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-base">{st.icon}</span>
                      <span className="text-[11px] font-black" style={{ color: st.color }}>{st.pct}%</span>
                    </div>
                    <div>
                      <p className="font-extrabold text-xs text-slate-800 truncate">{st.tag}</p>
                      <p className="text-[10px] font-bold text-slate-400">{st.completed}/{st.total} লেসন</p>
                    </div>
                    <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                      <div 
                        className="h-full rounded-full transition-all duration-700" 
                        style={{ width: `${st.pct}%`, backgroundColor: st.color }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Daily Goal & Quests Card */}
            {(() => {
              const pct = Math.min(100, Math.round((todayXp / DAILY_GOAL) * 100));
              const done = todayXp >= DAILY_GOAL;
              const R = 34, C = 2 * Math.PI * R;
              return (
                <div className={`rounded-3xl p-5 border-2 shadow-sm flex flex-col sm:flex-row items-center gap-5 ${done ? 'bg-sky-50 border-sky-300' : 'bg-white border-slate-200'}`}>
                  <div className="relative w-20 h-20 flex-shrink-0">
                    <svg viewBox="0 0 80 80" className="w-20 h-20 -rotate-90">
                      <circle cx="40" cy="40" r={R} fill="none" stroke="#e2e8f0" strokeWidth="9" />
                      <circle cx="40" cy="40" r={R} fill="none" stroke={done ? '#0ea5e9' : '#f59e0b'} strokeWidth="9" strokeLinecap="round" strokeDasharray={C} strokeDashoffset={C * (1 - pct / 100)} style={{ transition: 'stroke-dashoffset .8s ease' }} />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center font-black text-slate-700 text-sm">
                      {done ? '✅' : `${pct}%`}
                    </div>
                  </div>
                  <div className="flex-1 space-y-1 text-center sm:text-left">
                    <h3 className="font-black text-slate-800">
                      {done ? 'আজকের লক্ষ্য পূরণ! 🎉' : 'আজকের লক্ষ্য (Daily Goal)'}
                    </h3>
                    <p className="text-sm font-bold text-slate-500">
                      {todayXp} / {DAILY_GOAL} XP {done ? '— অসাধারণ ধারাবাহিকতা! কাল আবার আসুন।' : `— আর মাত্র ${DAILY_GOAL - todayXp} XP বাকি`}
                    </p>
                    <p className="text-xs font-bold text-amber-600">
                      {currentStreak > 0 ? `🔥 ${currentStreak} দিনের স্ট্রিক${done ? ' সুরক্ষিত!' : ' — আজ লেসন শেষ না করলে ভেঙে যেতে পারে!'}` : '🔥 আজই স্ট্রিক শুরু করুন!'}
                    </p>
                  </div>
                  <button
                    onClick={() => setShowQuestsModal(true)}
                    className="shrink-0 px-4 py-2.5 rounded-2xl bg-sky-500 hover:bg-sky-600 text-white font-black text-xs border-b-4 border-sky-700 active:border-b-0 active:translate-y-1 transition-all cursor-pointer"
                  >
                    🎯 মিশনসমূহ দেখুন
                  </button>
                </div>
              );
            })()}

            {/* Daily Quests Modal */}
            {showQuestsModal && (
              <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
                <div className="bg-white rounded-3xl border-2 border-slate-200 max-w-md w-full p-6 space-y-5 shadow-2xl relative animate-fadeIn">
                  <button 
                    onClick={() => setShowQuestsModal(false)}
                    className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-1"
                  >
                    <XCircle className="w-6 h-6" />
                  </button>

                  <div className="text-center space-y-1">
                    <div className="w-14 h-14 bg-sky-100 rounded-2xl flex items-center justify-center mx-auto text-3xl">🎯</div>
                    <h3 className="text-xl font-black text-slate-800">আজকের মিশন (Daily Quests)</h3>
                    <p className="text-xs text-slate-500 font-semibold">মিশন সম্পন্ন করে জিতে নিন বাড়তি XP ও জেম (Gems)!</p>
                  </div>

                  <div className="space-y-3">
                    {DAILY_QUESTS.map(q => {
                      const today = dayKey();
                      const isClaimed = userStats.claimedQuests[q.id] === today;
                      let progress = 0;
                      if (q.type === 'lessons') progress = todayLessons;
                      else if (q.type === 'words') progress = userStats.savedWords.length;
                      else if (q.type === 'streak') progress = currentStreak > 0 ? 1 : 0;
                      else if (q.type === 'score') progress = Object.values(hist).some(h => h.lastDate === today && h.last >= 80) ? 1 : 0;
                      
                      const canClaim = progress >= q.target && !isClaimed;

                      return (
                        <div key={q.id} className="p-3.5 rounded-2xl border-2 border-slate-200 flex items-center justify-between gap-3">
                          <div className="space-y-1">
                            <p className="font-extrabold text-sm text-slate-800 flex items-center gap-1.5">
                              <span>{q.icon}</span> {q.title}
                            </p>
                            <p className="text-xs font-bold text-slate-400">
                              অগ্রগতি: {Math.min(progress, q.target)}/{q.target} · পুরষ্কার: +{q.xp} XP · +{q.gems} 💎
                            </p>
                          </div>
                          <div>
                            {isClaimed ? (
                              <span className="text-xs font-black text-emerald-600 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200">
                                সম্পন্ন ✅
                              </span>
                            ) : canClaim ? (
                              <button
                                onClick={() => handleClaimQuest(q)}
                                className="px-3.5 py-1.5 bg-sky-500 hover:bg-sky-600 text-white font-black text-xs rounded-xl shadow-sm border-b-2 border-sky-700 cursor-pointer"
                              >
                                দাবি করুন 🎁
                              </button>
                            ) : (
                              <span className="text-xs font-bold text-slate-400 bg-slate-100 px-2.5 py-1 rounded-xl">
                                চলমান
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* Path Modules List */}
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <h2 className="text-xl sm:text-2xl font-black text-slate-800 flex items-center gap-2">
                  <Compass className="w-6 h-6 text-sky-600" />
                  শেখার পাঠ্যক্রম (Duolingo Learning Path)
                </h2>
                <span className="text-xs font-bold text-slate-400">
                  {userStats.completedLessons.length} / {ALL_CURRICULUM_PATH.reduce((n, m) => n + m.lessons.length, 0)} লেসন সম্পন্ন
                </span>
              </div>

              {/* Weak Modules Review Alert */}
              {weakModules.length > 0 && (
                <div className="bg-rose-50 border-2 border-rose-200 rounded-3xl p-5 space-y-3">
                  <h3 className="font-black text-rose-700 flex items-center gap-2">⚠️ অনুশীলন দরকার (Needs Practice)</h3>
                  {weakModules.map(m => {
                    const st = hist[m.id]; 
                    const ago = daysAgo(st.lastDate);
                    return (
                      <div key={m.id} className="flex items-center justify-between gap-3 bg-white rounded-2xl border border-rose-200 p-3">
                        <div>
                          <p className="font-extrabold text-sm text-slate-800">{m.icon} {m.title}</p>
                          <p className="text-xs font-semibold text-rose-600">
                            {st.last < 70 ? `শেষ স্কোর ${st.last}% (কম)` : `স্কোর ${st.last}%`} · শেষ অনুশীলন {agoText(ago)}
                          </p>
                        </div>
                        <button 
                          onClick={() => startModule(m)} 
                          className="px-3 py-2 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-black text-xs whitespace-nowrap cursor-pointer"
                        >
                          আবার দিন ↻
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Duolingo Progression Stage Tabs */}
              <div className="flex flex-wrap gap-2">
                {[
                  ['all', '🎯 সকল মূল পাঠ'],
                  ['A1', '🌱 A1 প্রারম্ভিক'],
                  ['A2', '🌿 A2 প্রাথমিক'],
                  ['B1', '⚡ B1 মধ্যবর্তী'],
                  ['B2', '💼 B2 উচ্চ-মধ্যবর্তী'],
                  ['C1', '👑 C1 পারদর্শী'],
                  ['word', `📚 শব্দকোষ (${ALL_WORDS_DATABASE.length})`],
                  ['sent', `💬 বাক্যসমূহ (${SENTENCE_BANK.length})`]
                ].map(([k, label]) => (
                  <button 
                    key={k} 
                    onClick={() => setSelectedStage(k)} 
                    className={`px-3.5 py-2 rounded-2xl border-2 font-black text-xs sm:text-sm transition-all cursor-pointer ${
                      selectedStage === k 
                        ? 'bg-sky-500 border-sky-700 text-white' 
                        : 'bg-white border-slate-200 text-slate-600 hover:border-sky-400'
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>

              {/* Path Units & Duo Wavy Nodes */}
              <div className="space-y-10">
                {displayedModules.map((module, mi) => {
                  const pal = UNIT_COLORS[mi % UNIT_COLORS.length];
                  const doneN = module.lessons.filter(l => userStats.completedLessons.includes(l.id)).length;
                  const nextIdx = module.lessons.findIndex(l => !userStats.completedLessons.includes(l.id));

                  return (
                    <section key={module.id} className="space-y-5">
                      <div 
                        className="rounded-2xl p-4 flex items-center justify-between gap-3 text-white" 
                        style={{ background: pal[0], borderBottom: `5px solid ${pal[1]}` }}
                      >
                        <div>
                          <p className="text-xs font-extrabold opacity-90">
                            {module.stageName || (module.kind === 'core' ? `ইউনিট ${module.kindNo}` : module.kind === 'word' ? 'শব্দ মডিউল' : 'বাক্য মডিউল')} · {doneN}/{module.lessons.length} সম্পন্ন
                          </p>
                          <h3 className="text-lg font-black leading-tight">{module.icon} {module.title}</h3>
                          <p className="text-sm font-semibold opacity-90">{module.desc}</p>
                        </div>
                        {module.kind === 'core' && (
                          <button 
                            onClick={() => startModule(module)} 
                            className="shrink-0 px-3 py-2 rounded-xl bg-white font-black text-xs cursor-pointer shadow-sm" 
                            style={{ color: pal[1], borderBottom: '4px solid #E5E5E5' }}
                          >
                            🔁 সম্পূর্ণ মডিউল
                          </button>
                        )}
                      </div>

                      {/* Duolingo Wavy Circular Nodes */}
                      <div className="flex flex-col items-center gap-6 py-2">
                        {module.lessons.map((lesson, li) => {
                          const lh = hist[lesson.id];
                          const isDone = userStats.completedLessons.includes(lesson.id);
                          const isNext = li === nextIdx;
                          const off = Math.round(Math.sin(li * 0.9) * 48);

                          return (
                            <div key={lesson.id} className="relative flex flex-col items-center" style={{ transform: `translateX(${off}px)` }}>
                              {isNext && (
                                <div 
                                  className="absolute -top-10 px-3 py-1.5 rounded-xl bg-white border-2 border-slate-200 font-black text-sm whitespace-nowrap animate-bounce shadow-md" 
                                  style={{ color: pal[1] }}
                                >
                                  শুরু করুন
                                </div>
                              )}
                              <button
                                onClick={() => startLesson(lesson)}
                                title={lesson.title}
                                aria-label={lesson.title}
                                className="duo-node w-[72px] h-[72px] rounded-full flex items-center justify-center text-white cursor-pointer"
                                style={{ 
                                  background: isDone ? '#FFC800' : pal[0], 
                                  boxShadow: `0 6px 0 ${isDone ? '#E5A800' : pal[1]}` 
                                }}
                              >
                                {isDone ? (
                                  <Check className="w-8 h-8 stroke-[4]" />
                                ) : lesson.isExam ? (
                                  <Trophy className="w-8 h-8 fill-current" />
                                ) : (
                                  <Play className="w-7 h-7 fill-current ml-1" />
                                )}
                              </button>
                              <p className="text-center text-xs font-extrabold text-slate-600 mt-3 max-w-[130px] leading-tight">
                                {lesson.title}
                              </p>
                              {lh && (
                                <span className="text-[11px] font-bold text-amber-600">
                                  {lh.last}% · +{lesson.xp} XP
                                </span>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </section>
                  );
                })}
              </div>
            </div>

          </div>
        )}

        {/* ---------------- TABS 2: 3000+ WORD BANK (শব্দকোষ) ---------------- */}
        {activeTab === 'dictionary' && (
          <div className="space-y-6 animate-fadeIn">
            
            <div className="bg-white rounded-3xl border-2 border-slate-200 p-6 shadow-sm space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-2xl font-black text-slate-800 flex items-center gap-2">
                    <BookOpen className="w-6 h-6 text-sky-600" />
                    {ALL_WORDS_DATABASE.length}টি সমৃদ্ধ ইংরেজি শব্দকোষ (Word Bank)
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-500 font-medium">
                    বাংলা অর্থ, ক্যাটাগরি, CEFR লেভেল (A1-C1) এবং সাউন্ডসহ যেকোনো শব্দ খুঁজুন।
                  </p>
                </div>
                
                {/* Word Stats */}
                <div className="bg-sky-50 border border-sky-200 px-4 py-2 rounded-2xl font-bold text-xs text-sky-700">
                  মোট সেভ করা শব্দ: {userStats.savedWords.length} টি
                </div>
              </div>

              {/* Search input & filters */}
              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <div className="relative flex-1">
                  <Search className="w-5 h-5 absolute left-3.5 top-3.5 text-slate-400" />
                  <input
                    type="text"
                    placeholder="ইংরেজি শব্দ বা বাংলা অর্থ দিয়ে খুঁজুন..."
                    value={searchTerm}
                    onChange={(e) => { setSearchTerm(e.target.value); setWordPage(1); }}
                    className="w-full pl-11 pr-4 py-3 rounded-2xl border-2 border-slate-200 focus:border-sky-500 focus:outline-none font-bold text-sm bg-slate-50"
                  />
                </div>

                <select
                  value={selectedLevel}
                  onChange={(e) => { setSelectedLevel(e.target.value); setWordPage(1); }}
                  className="px-4 py-3 rounded-2xl border-2 border-slate-200 bg-slate-50 font-bold text-sm focus:outline-none focus:border-sky-500"
                >
                  <option value="All">সকল স্তর (CEFR Level)</option>
                  <option value="A1">A1 প্রারম্ভিক</option>
                  <option value="A2">A2 প্রাথমিক</option>
                  <option value="B1">B1 মধ্যবর্তী</option>
                  <option value="B2">B2 উচ্চ-মধ্যবর্তী</option>
                  <option value="C1">C1 পারদর্শী</option>
                </select>

                <select
                  value={selectedCategory}
                  onChange={(e) => { setSelectedCategory(e.target.value); setWordPage(1); }}
                  className="px-4 py-3 rounded-2xl border-2 border-slate-200 bg-slate-50 font-bold text-sm focus:outline-none focus:border-sky-500"
                >
                  <option value="All">সকল ক্যাটাগরি ({ALL_CATEGORIES.length})</option>
                  {ALL_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
            </div>

            <div className="flex items-center justify-between px-1 text-xs font-extrabold text-slate-500">
              <span>পেজ {curWordPage} / {totalWordPages}</span>
              <span>শব্দ {filteredWords.length ? (curWordPage - 1) * PAGE_SIZE + 1 : 0}–{Math.min(curWordPage * PAGE_SIZE, filteredWords.length)} · মোট {filteredWords.length}টি</span>
            </div>

            {/* Word Grid Display */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {pagedWords.map((item) => {
                const isSaved = userStats.savedWords.some(w => w.id === item.id);
                return (
                  <div key={item.id} className="bg-white rounded-2xl border-2 border-slate-200 p-4 shadow-sm hover:border-sky-400 transition-all space-y-2 relative group">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] font-extrabold text-sky-600 bg-sky-50 border border-sky-200 rounded-full px-2 py-0.5">#{item.id}</span>
                          <span className="text-[10px] font-extrabold text-indigo-700 bg-indigo-50 border border-indigo-200 rounded-full px-2 py-0.5">{item.level}</span>
                          <span className="text-[10px] font-extrabold text-slate-500 bg-slate-100 rounded-full px-2 py-0.5">{item.category}</span>
                        </div>
                        <h4 className="font-black text-lg text-slate-800 mt-1">{item.word}</h4>
                        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">{item.pos}</span>
                      </div>
                      
                      <div className="flex items-center space-x-1">
                        <button
                          onClick={() => speakText(item.word, isSlowAudio)}
                          className="p-2 bg-sky-50 text-sky-600 rounded-xl hover:bg-sky-100 transition-colors cursor-pointer"
                          title="উচ্চারণ শুনুন"
                        >
                          <Volume2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => toggleSaveWord(item)}
                          className={`p-2 rounded-xl transition-colors cursor-pointer ${
                            isSaved ? 'bg-amber-100 text-amber-600' : 'bg-slate-100 text-slate-400 hover:text-slate-600'
                          }`}
                          title="শব্দটি সেভ করুন"
                        >
                          <Bookmark className="w-4 h-4 fill-current" />
                        </button>
                      </div>
                    </div>

                    <div className="border-t border-slate-100 pt-2 flex items-center justify-between text-xs sm:text-sm">
                      <span className="font-extrabold text-sky-700">{item.bn}</span>
                      {item.phonetic && <span className="text-slate-400 font-semibold italic">[{item.phonetic}]</span>}
                    </div>
                  </div>
                );
              })}
            </div>

            <Pager page={curWordPage} total={totalWordPages} onChange={goWordPage} />

            {filteredWords.length === 0 && (
              <div className="bg-white rounded-3xl p-8 text-center border-2 border-slate-200 space-y-2">
                <HelpCircle className="w-10 h-10 text-slate-300 mx-auto" />
                <p className="font-bold text-slate-600">কোনো শব্দ পাওয়া যায়নি!</p>
              </div>
            )}

          </div>
        )}

        {/* ---------------- TAB: 1000+ SENTENCE BANK ---------------- */}
        {activeTab === 'sentences' && (
          <div className="space-y-6 animate-fadeIn">
            {/* Sentence of the day */}
            <div className="bg-gradient-to-r from-sky-500 to-blue-600 rounded-3xl p-5 text-white shadow-lg flex items-center justify-between gap-4">
              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-widest text-sky-100">আজকের বাক্য · Sentence of the Day</span>
                <p className="text-xl font-black mt-1">{sentenceOfTheDay.en}</p>
                <p className="text-sm font-bold text-sky-100">{sentenceOfTheDay.bn}</p>
              </div>
              <button 
                onClick={() => speakText(sentenceOfTheDay.en, isSlowAudio)} 
                className="p-3 bg-white/20 hover:bg-white/30 rounded-2xl cursor-pointer"
              >
                <Volume2 className="w-6 h-6" />
              </button>
            </div>

            <div className="bg-white rounded-3xl border-2 border-slate-200 p-6 shadow-sm space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-2xl font-black text-slate-800 flex items-center gap-2">
                    <Sparkles className="w-6 h-6 text-sky-600" /> সেন্টেন্স ব্যাংক ({SENTENCE_BANK.length}টি বাস্তব বাক্য)
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-500 font-medium">রোজকার কাজের রেডিমেড বাক্য। শুনুন, বলুন, অনুশীলন করুন।</p>
                </div>
                <div className="flex gap-2 flex-wrap">
                  <button
                    onClick={() => { setOnlySaved(v => !v); setSentPage(1); }}
                    className={`px-4 py-2 rounded-2xl font-bold text-xs border-2 flex items-center gap-1.5 cursor-pointer ${
                      onlySaved ? 'bg-amber-100 border-amber-400 text-amber-700' : 'bg-slate-50 border-slate-200 text-slate-600'
                    }`}
                  >
                    <Bookmark className="w-4 h-4 fill-current" /> সেভ করা ({(userStats.savedSentences || []).length})
                  </button>
                  <button
                    onClick={() => setShowBn(v => !v)}
                    className={`px-4 py-2 rounded-2xl font-bold text-xs border-2 cursor-pointer ${
                      showBn ? 'bg-sky-50 border-sky-300 text-sky-700' : 'bg-amber-50 border-amber-300 text-amber-700'
                    }`}
                  >
                    {showBn ? 'বাংলা লুকান (নিজেকে পরীক্ষা করুন)' : 'বাংলা দেখান'}
                  </button>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                <input
                  value={sentSearch}
                  onChange={(e) => { setSentSearch(e.target.value); setSentPage(1); }}
                  placeholder="বাক্য খুঁজুন..."
                  className="flex-1 px-4 py-3 rounded-2xl border-2 border-slate-200 focus:border-sky-500 focus:outline-none font-bold text-sm bg-slate-50"
                />
                
                <select
                  value={sentLevel}
                  onChange={(e) => { setSentLevel(e.target.value); setSentPage(1); }}
                  className="px-4 py-3 rounded-2xl border-2 border-slate-200 bg-slate-50 font-bold text-sm focus:outline-none focus:border-sky-500"
                >
                  <option value="All">সকল স্তর (CEFR)</option>
                  <option value="A1">A1 প্রারম্ভিক</option>
                  <option value="A2">A2 প্রাথমিক</option>
                  <option value="B1">B1 মধ্যবর্তী</option>
                  <option value="B2">B2 উচ্চ-মধ্যবর্তী</option>
                  <option value="C1">C1 পারদর্শী</option>
                </select>

                <select
                  value={sentCat}
                  onChange={(e) => { setSentCat(e.target.value); setSentPage(1); }}
                  className="px-4 py-3 rounded-2xl border-2 border-slate-200 bg-slate-50 font-bold text-sm focus:outline-none focus:border-sky-500"
                >
                  <option value="All">সকল ক্যাটাগরি ({SENTENCE_CATEGORIES.length})</option>
                  {SENTENCE_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
            </div>

            <div className="flex items-center justify-between px-1 text-xs font-extrabold text-slate-500">
              <span>পেজ {curSentPage} / {totalSentPages}</span>
              <span>বাক্য {filteredSentences.length ? (curSentPage - 1) * PAGE_SIZE + 1 : 0}–{Math.min(curSentPage * PAGE_SIZE, filteredSentences.length)} · মোট {filteredSentences.length}টি</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {pagedSents.map(x => (
                <div key={x.id} className="bg-white rounded-2xl border-2 border-slate-200 p-4 shadow-sm hover:border-sky-400 transition-all flex items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[10px] font-extrabold text-sky-600 bg-sky-50 border border-sky-200 rounded-full px-2 py-0.5">#{x.id}</span>
                      <span className="text-[10px] font-extrabold text-indigo-700 bg-indigo-50 border border-indigo-200 rounded-full px-2 py-0.5">{x.level}</span>
                      <span className="text-[10px] font-extrabold text-slate-500 bg-slate-100 rounded-full px-2 py-0.5">{x.category}</span>
                    </div>
                    <p className="font-black text-slate-800 text-base">{x.en}</p>
                    {showBn && <p className="text-sm font-bold text-sky-700">{x.bn}</p>}
                  </div>
                  <div className="flex flex-col gap-1.5 shrink-0">
                    <button 
                      onClick={() => speakText(x.en, false)} 
                      className="p-2 bg-sky-50 text-sky-600 rounded-xl hover:bg-sky-100 cursor-pointer" 
                      title="শুনুন"
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => speakText(x.en, true)} 
                      className="p-2 bg-slate-100 text-slate-500 rounded-xl hover:bg-slate-200 cursor-pointer" 
                      title="ধীরে শুনুন (Slow Audio)"
                    >
                      <Turtle className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => toggleSaveSentence(x.id)} 
                      className={`p-2 rounded-xl cursor-pointer ${
                        (userStats.savedSentences || []).includes(x.id) 
                          ? 'bg-amber-100 text-amber-600' 
                          : 'bg-slate-100 text-slate-400 hover:text-slate-600'
                      }`} 
                      title="সেভ করুন"
                    >
                      <Bookmark className="w-4 h-4 fill-current" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <Pager page={curSentPage} total={totalSentPages} onChange={goSentPage} />
            {filteredSentences.length === 0 && (
              <p className="text-center font-bold text-slate-500 py-8">কোনো বাক্য পাওয়া যায়নি।</p>
            )}
          </div>
        )}

        {/* ---------------- TABS 3: LEADERBOARD & BADGES ---------------- */}
        {activeTab === 'leaderboard' && (
          <div className="space-y-6 animate-fadeIn">
            
            {/* Weekly Leaderboard */}
            <div className="bg-white rounded-3xl border-2 border-slate-200 p-6 shadow-sm space-y-6">
              <div className="text-center space-y-2">
                <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto text-3xl text-yellow-600 shadow-inner border-2 border-yellow-300">
                  🏆
                </div>
                <h2 className="text-2xl font-black text-slate-800">লীডারবোর্ড (Weekly Leaderboard)</h2>
                <p className="text-xs sm:text-sm text-slate-500 font-medium">প্রতি সপ্তাহে সর্বোচ্চ XP অর্জনকারী শিক্ষার্থীদের তালিকা</p>
              </div>

              <div className="space-y-3">
                {[
                  { rank: 1, name: 'তানভীর আহমেদ', xp: 520, level: 6, avatar: '👨‍🎓' },
                  { rank: 2, name: 'আপনি (You)', xp: userStats.xp, level: userStats.level, avatar: '🦉', isUser: true },
                  { rank: 3, name: 'নুসরাত জাহান', xp: 380, level: 4, avatar: '👩‍🏫' },
                  { rank: 4, name: 'আরিফ হোসেন', xp: 240, level: 3, avatar: '👨‍💻' },
                  { rank: 5, name: 'মেহেরুন নিসা', xp: 190, level: 2, avatar: '👩‍🎓' }
                ].sort((a,b) => b.xp - a.xp).map((user, idx) => (
                  <div 
                    key={idx}
                    className={`flex items-center justify-between p-4 rounded-2xl border-2 font-bold ${
                      user.isUser ? 'bg-sky-50 border-sky-400 text-sky-900 shadow-sm' : 'bg-white border-slate-200 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center space-x-4">
                      <span className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-sm ${
                        idx === 0 ? 'bg-yellow-400 text-slate-900' : idx === 1 ? 'bg-slate-300 text-slate-800' : 'bg-amber-600 text-white'
                      }`}>
                        #{idx + 1}
                      </span>
                      <span className="text-2xl">{user.avatar}</span>
                      <div>
                        <p className="font-extrabold text-sm sm:text-base">{user.name}</p>
                        <span className="text-xs text-slate-400 font-semibold">লেভেল {user.level} · {levelTitle(user.level)}</span>
                      </div>
                    </div>
                    <span className="font-black text-amber-500 text-sm sm:text-base flex items-center gap-1">
                      <Zap className="w-4 h-4 fill-amber-500" /> {user.xp} XP
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Achievements & Badges Grid */}
            <div className="bg-white rounded-3xl border-2 border-slate-200 p-6 shadow-sm space-y-4">
              <h3 className="text-xl font-black text-slate-800 flex items-center gap-2">
                <Award className="w-6 h-6 text-amber-500" />
                আপনার ব্যাজ ও অর্জন (Achievements)
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                {ACHIEVEMENTS.map(ach => {
                  let isUnlocked = false;
                  if (ach.type === 'lessons') isUnlocked = userStats.completedLessons.length >= ach.req;
                  else if (ach.type === 'words') isUnlocked = userStats.savedWords.length >= ach.req;
                  else if (ach.type === 'streak') isUnlocked = currentStreak >= ach.req;
                  else if (ach.type === 'sentences') isUnlocked = userStats.savedSentences.length >= ach.req;
                  else if (ach.type === 'xp') isUnlocked = userStats.xp >= ach.req;
                  else if (ach.type === 'exam') isUnlocked = (userStats.exams || []).some(e => e.pct >= 70);
                  else if (ach.type === 'perfect') isUnlocked = Object.values(hist).some(h => h.best === 100);

                  return (
                    <div 
                      key={ach.id} 
                      className={`p-4 rounded-2xl border-2 text-center space-y-1 transition-all ${
                        isUnlocked 
                          ? 'bg-amber-50/70 border-amber-300 shadow-sm' 
                          : 'bg-slate-50 border-slate-200 opacity-50'
                      }`}
                    >
                      <div className="text-3xl mb-1">{ach.icon}</div>
                      <h4 className="font-black text-sm text-slate-800">{ach.title}</h4>
                      <p className="text-[11px] font-bold text-slate-500">{ach.desc}</p>
                      <span className={`inline-block text-[10px] font-black px-2 py-0.5 rounded-full mt-2 ${
                        isUnlocked ? 'bg-amber-200 text-amber-900' : 'bg-slate-200 text-slate-500'
                      }`}>
                        {isUnlocked ? 'আনলকড্ ✅' : 'লকড্ 🔒'}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>
        )}

        {/* ---------------- TABS 4: SETTINGS & PROFILE ---------------- */}
        {activeTab === 'profile' && (
          <div className="space-y-6 animate-fadeIn">
            
            <div className="bg-white rounded-3xl border-2 border-slate-200 p-6 shadow-sm space-y-6">
              <div className="flex items-center space-x-4">
                <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-sky-400 to-sky-600 flex items-center justify-center text-4xl text-white shadow-md">
                  🦉
                </div>
                <div>
                  <h2 className="text-2xl font-black text-slate-800">শিক্ষার্থী ড্যাশবোর্ড</h2>
                  <p className="text-xs text-slate-400 font-bold">Fluently Learner Profile · লেভেল {userStats.level} ({levelTitle(userStats.level)})</p>
                </div>
              </div>

              <div className="grid grid-cols-4 gap-2 sm:gap-3 text-center">
                <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-3">
                  <p className="text-xl sm:text-2xl font-black text-yellow-600">{userStats.xp}</p>
                  <p className="text-[11px] font-bold text-slate-500">মোট XP</p>
                </div>
                <div className="bg-cyan-50 border border-cyan-200 rounded-2xl p-3">
                  <p className="text-xl sm:text-2xl font-black text-cyan-600">{userStats.gems}</p>
                  <p className="text-[11px] font-bold text-slate-500">জেম (💎)</p>
                </div>
                <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3">
                  <p className="text-xl sm:text-2xl font-black text-amber-600">{currentStreak}</p>
                  <p className="text-[11px] font-bold text-slate-500">টানা দিন (Streak)</p>
                </div>
                <div className="bg-sky-50 border border-sky-200 rounded-2xl p-3">
                  <p className="text-xl sm:text-2xl font-black text-sky-600">{(userStats.activeDays || []).length}</p>
                  <p className="text-[11px] font-bold text-slate-500">মোট দিন</p>
                </div>
              </div>

              {/* CEFR Stage Progress In Profile */}
              <div className="border-t border-slate-100 pt-6 space-y-3">
                <h3 className="font-black text-base text-slate-800 flex items-center gap-2">
                  <BarChart2 className="w-5 h-5 text-sky-600" /> CEFR লেভেল পারদর্শিতা
                </h3>
                <div className="space-y-2">
                  {stageProgress.map(st => (
                    <div key={st.id} className="flex items-center justify-between p-3 rounded-2xl border border-slate-200 bg-slate-50">
                      <div className="flex items-center gap-2.5">
                        <span className="text-lg">{st.icon}</span>
                        <div>
                          <p className="font-extrabold text-sm text-slate-800">{st.title}</p>
                          <p className="text-xs text-slate-500 font-semibold">{st.subtitle}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="font-black text-sm" style={{ color: st.color }}>{st.pct}%</span>
                        <p className="text-[11px] font-bold text-slate-400">{st.completed}/{st.total} সম্পন্ন</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Practice Exam */}
              <div className="border-t border-slate-100 pt-6 space-y-3">
                <h3 className="font-black text-base text-slate-800 flex items-center gap-2">
                  <Trophy className="w-5 h-5 text-amber-500" />
                  📝 পরীক্ষা ও মূল্যায়ন (Practice Exam)
                </h3>
                <p className="text-xs text-slate-500 font-semibold">
                  সম্পূর্ণ ৩০০০+ শব্দ ও ১০০০+ বাক্য থেকে ১০টি র‍্যান্ডম প্রশ্ন · পাস মার্ক ৭০% · যতবার খুশি দিতে পারবেন
                </p>
                <button 
                  onClick={startExam} 
                  className="w-full bg-indigo-500 hover:bg-indigo-600 text-white font-black py-3.5 rounded-2xl border-b-4 border-indigo-700 active:border-b-0 active:translate-y-1 transition-all cursor-pointer"
                >
                  পরীক্ষা শুরু করুন
                </button>
                {(userStats.exams || []).length > 0 && (
                  <div className="space-y-2 pt-2">
                    {[...userStats.exams].reverse().slice(0, 5).map((e, i) => (
                      <div key={i} className="flex items-center justify-between p-3 rounded-2xl border border-slate-200 text-sm font-bold">
                        <span className="text-slate-600">{e.date} ({agoText(daysAgo(e.date))})</span>
                        <span className={e.pct >= 70 ? 'text-sky-600 font-black' : 'text-rose-600 font-black'}>
                          {e.pct}% · {e.pct >= 70 ? 'পাস ✅' : 'ফেল ❌'}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* 7 Day Study Tracking */}
              <div className="border-t border-slate-100 pt-6 space-y-3">
                <h3 className="font-black text-base text-slate-800">📅 দৈনিক ট্র্যাকিং (শেষ ৭ দিন)</h3>
                {Array.from({ length: 7 }, (_, i) => dayKey(new Date(Date.now() - i * 86400000))).map(k => {
                  const d = (userStats.daily || {})[k];
                  return (
                    <div key={k} className={`flex items-center justify-between p-3 rounded-2xl border text-sm font-bold ${d ? 'bg-sky-50 border-sky-200 text-slate-800' : 'bg-slate-50 border-slate-200 text-slate-400'}`}>
                      <span>{k} {k === dayKey() && '(আজ)'}</span>
                      <span>{d ? `${d.xp} XP · ${d.lessons} লেসন · ${Math.max(1, Math.round(d.sec / 60))} মিনিট · ${Math.round((d.correct / Math.max(1, d.total)) * 100)}%` : 'শেখা হয়নি'}</span>
                    </div>
                  );
                })}
              </div>

              {/* Preferences Settings */}
              <div className="border-t border-slate-100 pt-6 space-y-4">
                <h3 className="font-black text-base text-slate-800 flex items-center gap-2">
                  <Settings className="w-5 h-5 text-sky-600" /> অ্যাপ সেটিংস (Settings)
                </h3>

                {/* Slow Audio Toggle for Seniors & Kids */}
                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-200">
                  <div className="flex items-center space-x-3">
                    <Turtle className="w-6 h-6 text-sky-600" />
                    <div>
                      <p className="font-bold text-sm text-slate-800">ধীরগতির অডিও (Slow Audio Mode)</p>
                      <span className="text-xs text-slate-500">শিশু ও বয়স্কদের ইংরেজি বুঝতে সুবিধাজনক</span>
                    </div>
                  </div>
                  <button
                    onClick={() => setIsSlowAudio(!isSlowAudio)}
                    className={`px-4 py-2 rounded-xl font-bold text-xs transition-colors cursor-pointer ${
                      isSlowAudio ? 'bg-sky-500 text-white' : 'bg-slate-200 text-slate-700'
                    }`}
                  >
                    {isSlowAudio ? 'অন (ON)' : 'অফ (OFF)'}
                  </button>
                </div>

                {/* Font Size Toggle */}
                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-200">
                  <div className="flex items-center space-x-3">
                    <Layers className="w-6 h-6 text-blue-600" />
                    <div>
                      <p className="font-bold text-sm text-slate-800">লেখার সাইজ (Font Size)</p>
                      <span className="text-xs text-slate-500">সহজে পড়ার জন্য বড় সাইজ বেছে নিন</span>
                    </div>
                  </div>
                  <button
                    onClick={() => setFontSize(fontSize === 'normal' ? 'large' : 'normal')}
                    className="px-4 py-2 bg-slate-200 font-bold text-xs text-slate-700 rounded-xl hover:bg-slate-300 cursor-pointer"
                  >
                    {fontSize === 'normal' ? 'সাধারণ (Normal)' : 'বড় (Large)'}
                  </button>
                </div>

              </div>
            </div>

          </div>
        )}

        {/* ---------------- TAB: ABOUT ---------------- */}
        {activeTab === 'about' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="rounded-3xl p-6 sm:p-8 text-white text-center space-y-3" style={{ background: '#1CB0F6', borderBottom: '6px solid #1899D6' }}>
              <div className="w-16 h-16 mx-auto rounded-2xl bg-white text-sky-600 flex items-center justify-center font-black text-4xl shadow-md">F</div>
              <h2 className="text-3xl font-black tracking-tight">Fluently</h2>
              <p className="font-bold text-sky-50 max-w-md mx-auto">বাংলাভাষী শিক্ষার্থীদের জন্য সহজ, ধাপে ধাপে ও আত্মবিশ্বাস জাগানো ডুওলিঙ্গো স্টাইলের ইংরেজি শেখার প্ল্যাটফর্ম।</p>
              <div className="grid grid-cols-3 gap-2 pt-2 text-center">
                <div className="bg-white/20 rounded-2xl py-2">
                  <p className="text-xl font-black">{ALL_WORDS_DATABASE.length}</p>
                  <p className="text-[11px] font-bold">শব্দ</p>
                </div>
                <div className="bg-white/20 rounded-2xl py-2">
                  <p className="text-xl font-black">{SENTENCE_BANK.length}</p>
                  <p className="text-[11px] font-bold">বাস্তব বাক্য</p>
                </div>
                <div className="bg-white/20 rounded-2xl py-2">
                  <p className="text-xl font-black">{ALL_CURRICULUM_PATH.reduce((n, m) => n + m.lessons.length, 0)}</p>
                  <p className="text-[11px] font-bold">লেসন</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-3xl border-2 border-slate-200 p-6 space-y-5">
              <h3 className="text-xs font-extrabold uppercase tracking-widest text-sky-600">প্রতিষ্ঠাতা · Founder</h3>
              <div className="flex items-center gap-4">
                <div className="w-20 h-20 rounded-full bg-sky-500 text-white flex items-center justify-center text-3xl font-black border-b-4 border-sky-700 shrink-0">TB</div>
                <div>
                  <h4 className="text-2xl font-black text-slate-800">Talha Belal</h4>
                  <p className="text-sm font-bold text-slate-500">Founder, Fluently</p>
                </div>
              </div>
              <a
                href="https://www.facebook.com/talha.belal.92"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl bg-sky-500 hover:bg-sky-600 text-white font-black text-sm border-b-4 border-sky-700 active:border-b-0 active:translate-y-1 transition-all"
              >
                <FacebookIcon className="w-5 h-5" /> Facebook-এ যোগাযোগ করুন <ExternalLink className="w-4 h-4" />
              </a>
            </div>

            <div className="bg-white rounded-3xl border-2 border-slate-200 p-6 space-y-3">
              <h3 className="text-xl font-black text-slate-800 flex items-center gap-2"><Target className="w-6 h-6 text-sky-600" /> কেন Fluently?</h3>
              <p className="text-sm sm:text-base font-semibold text-slate-600 leading-relaxed">
                অনেক বাংলাভাষী শিক্ষার্থী বছরের পর বছর ইংরেজি পড়েও কথা বলতে ভয় পান। তাঁদের সমস্যা মেধার নয়, সমস্যা হলো এমন একটি পথের অভাব যেখানে বাংলা অর্থ, সঠিক উচ্চারণ, বাস্তব বাক্য ও নিয়মিত গেমিফাইড অনুশীলন একসাথে পাওয়া যায়।
              </p>
              <p className="text-sm sm:text-base font-semibold text-slate-600 leading-relaxed">
                Talha Belal এই ঘাটতি পূরণের লক্ষ্য নিয়েই Fluently তৈরি করেছেন, যাতে প্রতিটি শিক্ষার্থী প্রতিদিন অল্প সময়ে, নিজের গতিতে, Beginner থেকে Advanced স্তরে ধাপে ধাপে ইংরেজি শিখতে পারেন এবং নিজের অগ্রগতি ট্র্যাক করতে পারেন।
              </p>
            </div>

            <div className="bg-sky-50 border-2 border-sky-200 rounded-3xl p-6 space-y-3">
              <h3 className="text-xl font-black text-sky-800">ইংরেজি শিখতে যারা শুরু করছেন, তাঁদের জন্য</h3>
              <ul className="space-y-2 text-sm sm:text-base font-bold text-sky-900">
                <li>✔ ভুল করা শেখারই অংশ। ভুল থেকেই ভাষা পাকা হয়।</li>
                <li>✔ প্রতিদিন মাত্র ১০ মিনিট নিয়মিত অনুশীলন, মাসের শেষে বিশাল পরিবর্তন আনে।</li>
                <li>✔ শব্দ মুখস্থ নয়, বাক্যে ব্যবহার করুন। জোরে বলুন, শুনুন, আবার বলুন।</li>
                <li>✔ অন্যের সাথে তুলনা নয়, গতকালের নিজের সাথে তুলনা করুন।</li>
              </ul>
              <p className="text-sm font-extrabold text-sky-700 pt-1">আপনি পারবেন। শুধু শুরুটা করুন, বাকিটা Fluently-র সঙ্গে ধাপে ধাপে এগোবে।</p>
            </div>

            <p className="text-center text-xs font-bold text-slate-400 pb-2">© {new Date().getFullYear()} Fluently · Founded by Talha Belal</p>
          </div>
        )}

        {/* ---------------- TABS 5: ACTIVE LESSON SCREEN ---------------- */}
        {activeTab === 'lesson' && activeLesson && (
          <div className="max-w-2xl mx-auto space-y-6 animate-fadeIn">
            
            {/* Top Progress Bar & Exit */}
            {!showSummary && (
              <div className="flex items-center space-x-4">
                <button 
                  onClick={() => setActiveTab('path')} 
                  className="text-slate-400 hover:text-slate-600 p-1 rounded-lg hover:bg-slate-100 cursor-pointer"
                >
                  <XCircle className="w-8 h-8" />
                </button>
                <div className="flex-1 bg-slate-200 rounded-full h-4 overflow-hidden border border-slate-300">
                  <div 
                    className="bg-sky-500 h-full rounded-full transition-all duration-500 ease-out" 
                    style={{ width: `${((questionIdx) / activeLesson.questions.length) * 100}%` }}
                  />
                </div>
                {combo >= 2 && (
                  <div key={combo} className="fl-pop flex items-center gap-1 bg-orange-100 border border-orange-300 text-orange-600 font-black text-sm px-3 py-1 rounded-full">
                    <Flame className="w-4 h-4 fill-orange-500" /> x{combo}
                  </div>
                )}
              </div>
            )}

            {/* LESSON SUMMARY VIEW WHEN COMPLETED */}
            {showSummary ? (
              <div className="bg-white rounded-3xl border-2 border-slate-200 p-8 text-center space-y-6 shadow-xl my-8">
                {pctNow >= 60 && <Confetti />}
                <div className="w-24 h-24 bg-yellow-100 text-yellow-600 rounded-full flex items-center justify-center mx-auto text-5xl shadow-inner border-4 border-yellow-300 animate-bounce">
                  🏆
                </div>
                <div>
                  <h2 className="text-2xl sm:text-3xl font-black text-slate-800">অসাধারণ! লেসন সফলভাবে সম্পন্ন হয়েছে!</h2>
                  <p className="text-slate-500 mt-1 font-bold">
                    {activeLesson.isExam 
                      ? (pctNow >= 70 ? '✅ পরীক্ষায় পাস করেছেন!' : '❌ পাস মার্ক ৭০%। আবার চেষ্টা করুন।') 
                      : pctNow >= 80 
                      ? 'চমৎকার পারফরম্যান্স!' 
                      : pctNow >= 60 
                      ? 'ভালো হয়েছে, আরেকবার অনুশীলন করলে আরও চমৎকার হবে।' 
                      : 'স্কোর কম, আবার অনুশীলন করুন।'}
                  </p>
                </div>

                <div className="grid grid-cols-3 gap-3 max-w-sm mx-auto">
                  <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3 text-center">
                    <span className="text-[10px] font-bold text-amber-600 uppercase">মোট XP</span>
                    <p className="text-xl font-black text-amber-700">+{activeLesson.xp + lessonXpEarned}</p>
                  </div>
                  <div className="bg-cyan-50 border border-cyan-200 rounded-2xl p-3 text-center">
                    <span className="text-[10px] font-bold text-cyan-600 uppercase">জেম</span>
                    <p className="text-xl font-black text-cyan-700">+{pctNow === 100 ? 5 : 2} 💎</p>
                  </div>
                  <div className="bg-sky-50 border border-sky-200 rounded-2xl p-3 text-center">
                    <span className="text-[10px] font-bold text-sky-600 uppercase">সঠিক উত্তর</span>
                    <p className="text-xl font-black text-sky-700">{pctNow}%</p>
                  </div>
                </div>

                <div className="flex flex-wrap justify-center gap-2">
                  {pctNow === 100 && <span className="fl-pop bg-yellow-100 text-yellow-700 border border-yellow-300 font-black text-xs px-3 py-1.5 rounded-full">💎 পারফেক্ট লেসন!</span>}
                  {bestCombo >= 3 && <span className="fl-pop bg-orange-100 text-orange-700 border border-orange-300 font-black text-xs px-3 py-1.5 rounded-full">🔥 সেরা কম্বো x{bestCombo}</span>}
                  {userStats.level > levelAtStartRef.current && <span className="fl-pop bg-indigo-100 text-indigo-700 border border-indigo-300 font-black text-xs px-3 py-1.5 rounded-full">⬆️ লেভেল আপ! {levelTitle(userStats.level)}</span>}
                </div>

                <div className="space-y-3">
                  <button
                    onClick={() => startLesson(activeLesson)}
                    className="w-full bg-indigo-500 hover:bg-indigo-600 text-white font-black py-4 rounded-2xl shadow-lg border-b-4 border-indigo-700 active:border-b-0 active:translate-y-1 transition-all text-lg cursor-pointer"
                  >
                    🔁 আবার অনুশীলন করুন
                  </button>
                  <button
                    onClick={() => setActiveTab('path')}
                    className="w-full bg-sky-500 hover:bg-sky-600 text-white font-black py-4 rounded-2xl shadow-lg border-b-4 border-sky-700 active:border-b-0 active:translate-y-1 transition-all text-lg cursor-pointer"
                  >
                    পাঠ্যক্রম তালিকায় ফিরুন
                  </button>
                </div>
              </div>
            ) : (
              /* ACTIVE QUESTION CARD */
              <div className="bg-white rounded-3xl border-2 border-slate-200 p-6 sm:p-8 shadow-sm space-y-6 min-h-[400px] flex flex-col justify-between">
                
                {(() => {
                  const q = activeLesson.questions[questionIdx];
                  if (!q) return null;

                  return (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black uppercase tracking-wider text-slate-400 bg-slate-100 px-3.5 py-1.5 rounded-full">
                          প্রশ্ন {questionIdx + 1} / {activeLesson.questions.length}
                        </span>
                        <button 
                          onClick={() => speakText(q.questionEn || q.audioText || "", isSlowAudio)}
                          className="flex items-center gap-1.5 text-xs font-bold text-sky-600 bg-sky-50 px-3 py-1.5 rounded-full hover:bg-sky-100 transition-colors cursor-pointer"
                        >
                          <Volume2 className="w-4 h-4" /> সাউন্ড শুনুন {isSlowAudio && '(Slow)'}
                        </button>
                      </div>

                      <h2 className="text-lg sm:text-xl font-extrabold text-slate-800">
                        {q.prompt}
                      </h2>

                      {/* Display Main English Phrase */}
                      {q.questionEn && q.type !== 'listening' && (
                        <div className="flex items-center space-x-3 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                          <button 
                            onClick={() => speakText(q.questionEn || "", isSlowAudio)} 
                            className="p-3 bg-sky-500 hover:bg-sky-600 text-white rounded-xl shadow transition-transform active:scale-95 cursor-pointer"
                          >
                            <Volume2 className="w-5 h-5" />
                          </button>
                          <span className="text-xl font-black tracking-wide text-slate-800">
                            "{q.questionEn}"
                          </span>
                        </div>
                      )}

                      {/* QUESTION TYPE 1: MULTIPLE CHOICE */}
                      {q.type === 'mcq' && q.options && (
                        <div className="grid grid-cols-1 gap-3 pt-2">
                          {q.options.map((opt, idx) => (
                            <button
                              key={idx}
                              onClick={() => setSelectedOpt(opt)}
                              className={`w-full p-4 rounded-2xl border-2 text-left font-bold text-base transition-all flex items-center justify-between cursor-pointer ${
                                selectedOpt === opt
                                  ? 'border-sky-500 bg-sky-50 text-sky-900 shadow-sm'
                                  : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                              }`}
                            >
                              <span>{opt}</span>
                              <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                                selectedOpt === opt ? 'border-sky-500 bg-sky-500 text-white' : 'border-slate-300'
                              }`}>
                                {selectedOpt === opt && <Check className="w-4 h-4 stroke-[3]" />}
                              </div>
                            </button>
                          ))}
                        </div>
                      )}

                      {/* QUESTION TYPE 2: REORDER (WORD TILES) */}
                      {q.type === 'reorder' && (
                        <div className="space-y-6 pt-2">
                          <div className="min-h-[75px] bg-slate-50 rounded-2xl border-2 border-dashed border-slate-300 p-3 flex flex-wrap gap-2 items-center">
                            {reorderedWords.length === 0 ? (
                              <span className="text-slate-400 text-xs sm:text-sm font-medium italic">
                                নিচে থেকে সঠিক শব্দে ট্যাপ করে বাক্য তৈরি করুন...
                              </span>
                            ) : (
                              reorderedWords.map((word, idx) => (
                                <button
                                  key={idx}
                                  onClick={() => {
                                    setReorderedWords(prev => prev.filter((_, i) => i !== idx));
                                    setAvailableWords(prev => [...prev, word]);
                                  }}
                                  className="bg-white border-2 border-slate-200 px-3.5 py-2 rounded-xl text-slate-800 font-bold shadow-sm hover:border-rose-300 transition-colors cursor-pointer"
                                >
                                  {word}
                                </button>
                              ))
                            )}
                          </div>

                          <div className="flex flex-wrap gap-2 justify-center">
                            {availableWords.map((word, idx) => (
                              <button
                                key={idx}
                                onClick={() => {
                                  setAvailableWords(prev => prev.filter((_, i) => i !== idx));
                                  setReorderedWords(prev => [...prev, word]);
                                }}
                                className="bg-slate-100 hover:bg-slate-200 border-2 border-slate-300 text-slate-800 font-extrabold px-4 py-2.5 rounded-2xl shadow-sm transition-all text-base cursor-pointer"
                              >
                                {word}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* QUESTION TYPE 3: LISTENING PRACTICE */}
                      {q.type === 'listening' && q.audioText && q.options && (
                        <div className="space-y-6 text-center pt-2">
                          <button
                            onClick={() => speakText(q.audioText || "", isSlowAudio)}
                            className="mx-auto w-24 h-24 bg-sky-500 hover:bg-sky-600 text-white rounded-3xl flex items-center justify-center shadow-lg border-b-4 border-sky-700 active:translate-y-1 transition-all group cursor-pointer"
                          >
                            <Volume2 className="w-12 h-12 group-hover:scale-110 transition-transform" />
                          </button>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            {q.options.map((opt, idx) => (
                              <button
                                key={idx}
                                onClick={() => setSelectedOpt(opt)}
                                className={`p-4 rounded-2xl border-2 font-bold text-slate-700 transition-all cursor-pointer ${
                                  selectedOpt === opt
                                    ? 'border-sky-500 bg-sky-50 text-sky-900 shadow-sm'
                                    : 'border-slate-200 bg-white hover:border-slate-300'
                                }`}
                              >
                                {opt}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* QUESTION TYPE 4: PAIR MATCHING */}
                      {q.type === 'matching' && q.pairs && (
                        <div className="grid grid-cols-2 gap-4 pt-2">
                          <div className="space-y-2">
                            <span className="text-xs font-bold text-slate-400 block text-center mb-1 uppercase">ENGLISH</span>
                            {q.pairs.map((pair, idx) => {
                              const isMatched = !!matchedPairs[pair.en];
                              const isSelected = selectedEn === pair.en;
                              return (
                                <button
                                  key={idx}
                                  disabled={isMatched}
                                  onClick={() => setSelectedEn(pair.en)}
                                  className={`w-full p-3.5 rounded-xl border-2 font-bold text-sm transition-all cursor-pointer ${
                                    isMatched 
                                      ? 'bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed opacity-50' 
                                      : isSelected 
                                      ? 'border-sky-500 bg-sky-50 text-sky-900' 
                                      : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                                  }`}
                                >
                                  {pair.en}
                                </button>
                              );
                            })}
                          </div>

                          <div className="space-y-2">
                            <span className="text-xs font-bold text-slate-400 block text-center mb-1 uppercase">বাংলা অর্থ</span>
                            {q.pairs.map((pair, idx) => {
                              const matchedEn = Object.keys(matchedPairs).find(key => matchedPairs[key] === pair.bn);
                              return (
                                <button
                                  key={idx}
                                  disabled={!!matchedEn}
                                  onClick={() => {
                                    if (selectedEn && q.pairs) {
                                      const targetPair = q.pairs.find(p => p.en === selectedEn);
                                      if (targetPair && targetPair.bn === pair.bn) {
                                        setMatchedPairs(prev => ({ ...prev, [selectedEn]: pair.bn }));
                                        playSound('correct');
                                      } else {
                                        playSound('wrong');
                                      }
                                      setSelectedEn(null);
                                    }
                                  }}
                                  className={`w-full p-3.5 rounded-xl border-2 font-bold text-sm transition-all cursor-pointer ${
                                    matchedEn 
                                      ? 'bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed opacity-50' 
                                      : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                                  }`}
                                >
                                  {pair.bn}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      )}

                    </div>
                  );
                })()}

                {/* BOTTOM ACTION BUTTON / FEEDBACK FOOTER */}
                <div className="pt-4 border-t border-slate-100">
                  {isAnswerChecked && (
                    <div className={`p-4 rounded-2xl mb-4 flex items-start space-x-3 ${
                      isCorrect ? 'bg-sky-100 border border-sky-300 text-sky-900' : 'bg-rose-100 border border-rose-300 text-rose-900'
                    }`}>
                      {isCorrect ? (
                        <CheckCircle2 className="w-6 h-6 text-sky-600 flex-shrink-0 mt-0.5" />
                      ) : (
                        <XCircle className="w-6 h-6 text-rose-600 flex-shrink-0 mt-0.5" />
                      )}
                      <div className="space-y-1">
                        <h4 className="font-extrabold text-base">
                          {isCorrect ? 'অসাধারণ! উত্তরটি সঠিক হয়েছে।' : 'ভুল উত্তর!'}
                        </h4>
                        {isCorrect && comboToast && <p className="fl-pop text-sm font-black text-orange-600">{comboToast}</p>}
                        {activeLesson.questions[questionIdx]?.hint && (
                          <p className="text-xs font-semibold opacity-90">
                            💡 ব্যাখ্যামূলক টিপস: {activeLesson.questions[questionIdx].hint}
                          </p>
                        )}
                      </div>
                    </div>
                  )}

                  {!isAnswerChecked ? (
                    <button
                      onClick={handleCheckAnswer}
                      className="w-full bg-sky-500 hover:bg-sky-600 text-white font-black py-4 rounded-2xl shadow-md border-b-4 border-sky-700 active:border-b-0 active:translate-y-1 transition-all text-base cursor-pointer"
                    >
                      উত্তর যাচাই করুন (Check Answer)
                    </button>
                  ) : (
                    <button
                      onClick={handleNextQuestion}
                      className={`w-full font-black py-4 rounded-2xl shadow-md border-b-4 active:border-b-0 active:translate-y-1 transition-all text-base text-white cursor-pointer ${
                        isCorrect ? 'bg-sky-500 hover:bg-sky-600 border-sky-700' : 'bg-rose-500 hover:bg-rose-600 border-rose-700'
                      }`}
                    >
                      পরবর্তী প্রশ্ন (Continue)
                    </button>
                  )}
                </div>

              </div>
            )}
          </div>
        )}

      </main>

      {/* ================= BOTTOM NAVIGATION BAR ================= */}
      {activeTab !== 'lesson' && (
        <footer className="sticky bottom-0 bg-white border-t-2 border-slate-200 py-3 px-4 z-30 shadow-lg">
          <div className="max-w-2xl mx-auto flex items-center justify-between gap-1">
            
            <button
              onClick={() => setActiveTab('path')}
              className={`flex flex-col items-center space-y-1 px-3 py-1 rounded-2xl transition-all cursor-pointer ${
                activeTab === 'path' ? 'text-sky-600 font-extrabold bg-sky-50' : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <Home className="w-6 h-6" />
              <span className="text-[11px] font-bold">শিখুন (Path)</span>
            </button>

            <button
              onClick={() => setActiveTab('dictionary')}
              className={`flex flex-col items-center space-y-1 px-3 py-1 rounded-2xl transition-all cursor-pointer ${
                activeTab === 'dictionary' ? 'text-sky-600 font-extrabold bg-sky-50' : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <BookOpen className="w-6 h-6" />
              <span className="text-[11px] font-bold">শব্দকোষ ({ALL_WORDS_DATABASE.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('sentences')}
              className={`flex flex-col items-center space-y-1 px-3 py-1 rounded-2xl transition-all cursor-pointer ${
                activeTab === 'sentences' ? 'text-sky-600 font-extrabold bg-sky-50' : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <Sparkles className="w-6 h-6" />
              <span className="text-[11px] font-bold">বাক্য ({SENTENCE_BANK.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('leaderboard')}
              className={`flex flex-col items-center space-y-1 px-3 py-1 rounded-2xl transition-all cursor-pointer ${
                activeTab === 'leaderboard' ? 'text-sky-600 font-extrabold bg-sky-50' : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <Trophy className="w-6 h-6" />
              <span className="text-[11px] font-bold">র‍্যাঙ্ক ও ব্যাজ</span>
            </button>

            <button
              onClick={() => setActiveTab('profile')}
              className={`flex flex-col items-center space-y-1 px-3 py-1 rounded-2xl transition-all cursor-pointer ${
                activeTab === 'profile' ? 'text-sky-600 font-extrabold bg-sky-50' : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <User className="w-6 h-6" />
              <span className="text-[11px] font-bold">প্রোফাইল</span>
            </button>

            <button
              onClick={() => setActiveTab('about')}
              className={`flex flex-col items-center space-y-1 px-3 py-1 rounded-2xl transition-all cursor-pointer ${
                activeTab === 'about' ? 'text-sky-600 font-extrabold bg-sky-50' : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <Info className="w-6 h-6" />
              <span className="text-[11px] font-bold">About</span>
            </button>

          </div>
        </footer>
      )}

    </div>
  );
}
