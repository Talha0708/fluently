// scripts/generate_rich_dataset.mjs
import fs from 'fs';
import path from 'path';

console.log('Building high-volume dataset...');

// We will load the initial data from fluently_step3_37e05570.tsx first to keep 100% backward compatibility
const originalFile = fs.readFileSync('public/assets/aistudio/fluently_step3_37e05570.tsx', 'utf8');

// Extract BASE_DICTIONARY
const baseMatch = originalFile.match(/const BASE_DICTIONARY = (\[[\s\S]*?\]);/);
const wordBankRawMatch = originalFile.match(/const WORD_BANK_RAW = (\{[\s\S]*?\});/);
const sentenceRawMatch = originalFile.match(/const SENTENCE_RAW = \`([\s\S]*?)\`;/);

console.log('Matches:', !!baseMatch, !!wordBankRawMatch, !!sentenceRawMatch);
